-- Forever Companion — CraftProfit.lua
-- Bénéfice dans la fenêtre de métier du jeu (ProfessionsFrame, chargée à la demande par Blizzard_Professions) :
--  · liste des recettes (à gauche) : bénéfice à la fin de chaque ligne (vente à l'HV − 5 % − composants) ;
--  · détail de la recette : prix de chaque composant (marchand ou HV) à droite de sa case, puis un bloc
--    composants / vente à l'HV / bénéfice ; pour un enchanteur, la valeur de désenchantement de l'objet fabriqué.
-- Rien ne change dans le fonctionnement de la fenêtre : nos textes sont posés après le jeu (hooksecurefunc) ;
-- seule la largeur du nom d'une recette est réduite quand notre texte prendrait sa place.
-- Option : Options > Professions (prof_window_profit, cochée par défaut).
local FC = ForeverCompanion
local API = ForeverCompanionAPI

local BASIC = (Enum and Enum.CraftingReagentType and Enum.CraftingReagentType.Basic) or 1
local CUT = 0.95                    -- taxe de l'HV : 5 %
local ENCHANTING, DISENCHANT = 333, 13262
local GRAY = "|cff9d9d9d"
local LINE_H, BLOCK_W = 13, 300     -- bloc du détail : hauteur d'une ligne, largeur sous les composants
local BOTTOM_ROOM = 40              -- bas du détail réservé au jeu (« Suivre la recette », source de la recette)

local function On() return FC.db ~= nil and FC.db.global.prof_window_profit ~= false end

-- ── Calcul ───────────────────────────────────────────────────────────────
-- Recette : objet fabriqué, quantité min / max, composants de base (fixes : gardés en cache)
local schem = {}
local function Schematic(recipeID)
    if type(recipeID) ~= "number" then return nil end
    if schem[recipeID] then return schem[recipeID] end
    local T = C_TradeSkillUI
    if not (T and T.GetRecipeSchematic) then return nil end
    local ok, sch = pcall(T.GetRecipeSchematic, recipeID, false)
    if not ok or type(sch) ~= "table" then return nil end
    local s = { rg = {} }
    if (sch.outputItemID or 0) > 0 then
        s.out = sch.outputItemID
        s.qmin = math.max(1, sch.quantityMin or 1)
        s.qmax = math.max(s.qmin, sch.quantityMax or s.qmin)
    end
    for _, slot in ipairs(sch.reagentSlotSchematics or {}) do
        local rg = slot.reagents and slot.reagents[1]
        if (slot.reagentType == nil or slot.reagentType == BASIC) and rg and rg.itemID then
            s.rg[#s.rg + 1] = { rg.itemID, slot.quantityRequired or 1 }
        end
    end
    schem[recipeID] = s
    return s
end

-- Prix d'achat d'un composant : prix unitaire, source ("vendor", "ah", "site" = prix indicatif)
local function BuyPrice(id)
    if FC.GetBuyPrice then
        local p, src = FC:GetBuyPrice(id)
        if p then return p, src end
    end
    local d = FC.CraftItems and FC.CraftItems[id]
    if d and d.p then return d.p, "site" end
end

local function IsEnchanter()
    if GetProfessions and GetProfessionInfo then
        local res = { pcall(GetProfessions) }
        if res[1] then
            for i = 2, 6 do   -- métier 1, métier 2, archéologie, pêche, cuisine (des trous possibles)
                local idx = res[i]
                if idx then
                    local ok, _, _, _, _, _, _, sl = pcall(GetProfessionInfo, idx)
                    if ok and sl == ENCHANTING then return true end
                end
            end
        end
    end
    if IsPlayerSpell then
        local ok, v = pcall(IsPlayerSpell, DISENCHANT)
        if ok and v then return true end
    end
    return false
end

-- Coût des composants, valeur à l'HV de ce qui est fabriqué, bénéfice après la taxe ;
-- withDE : valeur de désenchantement de ce qui est fabriqué, et bénéfice si on le désenchante
function FC:CraftEconomics(recipeID, withDE)
    local s = Schematic(recipeID)
    if not s then return nil end
    local e = { cost = 0, missing = 0, parts = {}, out = s.out, qmin = s.qmin, qmax = s.qmax }
    for _, r in ipairs(s.rg) do
        local p, src = BuyPrice(r[1])
        e.parts[#e.parts + 1] = { id = r[1], n = r[2], unit = p, src = src }
        if p then e.cost = e.cost + p * r[2] else e.missing = e.missing + 1 end
        if src == "site" then e.est = true end
    end
    if s.out then
        local q = (s.qmin + s.qmax) / 2
        local p, src
        if FC.GetItemPrice then p, src = FC:GetItemPrice(s.out) end
        if p then
            e.value, e.valueEst = math.floor(p * q + 0.5), src ~= "ah"
            e.profit = math.floor(e.value * CUT + 0.5) - e.cost
        end
        if withDE and FC.DisenchantValue then
            local v, miss = FC:DisenchantValue(s.out)
            if v and v > 0 then
                e.de, e.deMissing = math.floor(v * q + 0.5), miss or 0
                e.deProfit = math.floor(e.de * CUT + 0.5) - e.cost
            end
        end
    end
    return e
end

local function Signed(c)
    return (c >= 0 and ("|cff40bf40+" .. API.Money(c, true)) or ("|cffff5050" .. API.Money(c, true))) .. "|r"
end
local function Unsure(e) return (e.missing > 0 or e.est or e.valueEst) and (GRAY .. " ?|r") or "" end
local function SourceTag(src) return src == "vendor" and "vendor" or src == "ah" and "AH" or "est." end
local function QtyText(e)
    if not e.qmin or e.qmax <= 1 then return "" end
    return " (x" .. (e.qmin == e.qmax and tostring(e.qmin) or (e.qmin .. "-" .. e.qmax)) .. ")"
end

local gen = 0   -- augmente quand les prix ou l'option changent : textes à recalculer

-- ── Liste des recettes ───────────────────────────────────────────────────
local deco = setmetatable({}, { __mode = "k" })       -- [bouton] = { fs, id, gen, w = largeur du nom donnée par le jeu }
local hookedBtn = setmetatable({}, { __mode = "k" })

local function RecipeOf(node)
    if type(node) ~= "table" or type(node.GetData) ~= "function" then return nil end
    local ok, data = pcall(node.GetData, node)
    local info = ok and type(data) == "table" and data.recipeInfo
    return type(info) == "table" and info.recipeID or nil
end

-- fresh : le jeu vient de remplir la ligne (il a redonné sa largeur au nom)
local function Decorate(btn, node, fresh)
    if type(btn) ~= "table" then return end
    if node == nil and type(btn.GetElementData) == "function" then
        local ok, n = pcall(btn.GetElementData, btn); node = ok and n or nil
    end
    local id = RecipeOf(node)
    local d = deco[btn]
    if not d then
        if not id or type(btn.CreateFontString) ~= "function" then return end   -- catégorie, séparateur
        d = { fs = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") }
        d.fs:SetPoint("RIGHT", btn, "RIGHT", -2, 0)
        d.fs:SetJustifyH("RIGHT")
        deco[btn] = d
    end
    local label = btn.Label
    if fresh then d.w = nil end
    if not fresh and d.id == id and d.gen == gen then return end
    d.id, d.gen = id, gen
    local e = id and On() and FC:CraftEconomics(id)
    if not (e and e.profit) then
        d.fs:Hide()
        if label and d.w and label.SetWidth then label:SetWidth(d.w) end   -- largeur rendue au nom
        d.w = nil
        return
    end
    d.fs:SetText(Signed(e.profit) .. Unsure(e))
    d.fs:Show()
    -- Le nom (et le nombre fabricable qui le suit) s'arrête avant notre texte
    if label and label.GetWidth and label.SetWidth then
        if not d.w then d.w = label:GetWidth() end
        local left = 21   -- le nom commence après la case des points de compétence
        local bl, ll = btn.GetLeft and btn:GetLeft(), label.GetLeft and label:GetLeft()
        if type(bl) == "number" and type(ll) == "number" and ll > bl then left = ll - bl end
        local count = btn.Count
        local countW = (count and count.IsShown and count:IsShown() and count.GetStringWidth and count:GetStringWidth()) or 0
        local avail = (btn:GetWidth() or 0) - left - countW - (d.fs:GetStringWidth() or 0) - 6
        label:SetWidth(math.max(20, math.min(d.w or avail, avail)))
    end
end

local function HookButton(btn)
    if type(btn) ~= "table" or hookedBtn[btn] or type(btn.Init) ~= "function" then return end
    hookedBtn[btn] = true
    hooksecurefunc(btn, "Init", function(self, node) Decorate(self, node, true) end)
end

local function EachListFrame(sb)
    if type(sb) ~= "table" or type(sb.ForEachFrame) ~= "function" then return end
    pcall(sb.ForEachFrame, sb, function(frame, node) HookButton(frame); Decorate(frame, node, false) end)
end

-- ── Détail de la recette ─────────────────────────────────────────────────
local holder, panel
local rgText = {}        -- prix à droite de chaque case de composant
local mode               -- "below" (sous les composants) ou "side" (à droite, faute de place)
local placeToken = 0
local lastId

local function PanelTooltip(self)
    local e = self.e
    if not e then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:AddLine("Reagents", 1, 0.82, 0)
    for _, p in ipairs(e.parts) do
        local name = API.GetItemInfo(p.id) or ("item " .. p.id)
        GameTooltip:AddDoubleLine(name .. " x" .. p.n,
            p.unit and (API.Money(p.unit * p.n, true) .. GRAY .. "  " .. API.Money(p.unit, true) .. " each, " .. SourceTag(p.src) .. "|r")
                or (GRAY .. "no price|r"), 1, 1, 1, 1, 1, 1)
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Reagents: the cheaper of the vendor price (for those sold by vendors) and the Auction House price.", 0.6, 0.6, 0.6, true)
    GameTooltip:AddLine("Profit: Auction House price of what it makes, minus the 5% cut, minus the reagents.", 0.6, 0.6, 0.6, true)
    if e.est or e.valueEst then GameTooltip:AddLine("est.: estimated price, not seen at the Auction House yet.", 0.6, 0.6, 0.6, true) end
    GameTooltip:Show()
end

local function Build(form)
    holder = CreateFrame("Frame", nil, form)
    holder:SetAllPoints(form)
    holder:SetFrameLevel((form:GetFrameLevel() or 0) + 10)
    panel = CreateFrame("Frame", nil, holder)
    panel:SetSize(BLOCK_W, LINE_H)
    panel.lines = {}
    panel:EnableMouse(true)
    panel:SetScript("OnEnter", PanelTooltip)
    panel:SetScript("OnLeave", function() GameTooltip:Hide() end)
    panel:Hide()
end

local function Line(i)
    local l = panel.lines[i]
    if not l then
        l = { a = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"),
              b = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") }
        l.a:SetPoint("TOPLEFT", panel, "TOPLEFT", 0, -(i - 1) * LINE_H); l.a:SetJustifyH("LEFT")
        l.b:SetPoint("TOPRIGHT", panel, "TOPRIGHT", 0, -(i - 1) * LINE_H); l.b:SetJustifyH("RIGHT")
        panel.lines[i] = l
    end
    return l
end

-- Cases des composants de base affichées, de haut en bas
local function BasicSlots(form)
    local list = {}
    local rs
    if type(form.GetSlotsByReagentType) == "function" then
        local ok, v = pcall(form.GetSlotsByReagentType, form, BASIC); rs = ok and v or nil
    end
    if type(rs) ~= "table" then rs = type(form.reagentSlots) == "table" and form.reagentSlots[BASIC] end
    if type(rs) == "table" then
        for _, slot in ipairs(rs) do
            if type(slot) == "table" and slot.IsShown and slot:IsShown() then list[#list + 1] = slot end
        end
        if #list > 0 then return list end
    end
    local box = form.Reagents
    if type(box) == "table" and box.GetChildren then
        for _, c in ipairs({ box:GetChildren() }) do
            if type(c) == "table" and c.IsShown and c:IsShown() and c.Name and c.Button then list[#list + 1] = c end
        end
        table.sort(list, function(a, b)
            local ta, tb = a:GetTop() or 0, b:GetTop() or 0
            if math.abs(ta - tb) >= 1 then return ta > tb end
            return (a:GetLeft() or 0) < (b:GetLeft() or 0)
        end)
    end
    return list
end

-- Objet et quantité d'une case (sinon : même ordre que la recette)
local function SlotReagent(slot, i, e)
    if type(slot.GetReagentSlotSchematic) == "function" then
        local ok, sch = pcall(slot.GetReagentSlotSchematic, slot)
        local rg = ok and type(sch) == "table" and sch.reagents and sch.reagents[1]
        if rg and rg.itemID then return rg.itemID, sch.quantityRequired or 1 end
    end
    local p = e.parts[i]
    if p then return p.id, p.n end
end

-- Place le bloc : sous les composants s'il y a la place, sinon à droite de leurs cases (les prix
-- par composant sont alors dans l'info-bulle du bloc)
local function Place(form, slots)
    local first, last = slots[1], slots[#slots]
    local opt = form.OptionalReagents
    local below = not (opt and opt.IsShown and opt:IsShown())
    if below then
        local pb, fb = panel:GetBottom(), form:GetBottom()
        if type(pb) == "number" and type(fb) == "number" and pb < fb + BOTTOM_ROOM then below = false end
    end
    -- Composants sur plusieurs colonnes : pas de place à droite de leurs cases
    local multi = false
    for i = 2, #slots do
        local a, b = slots[i - 1]:GetTop(), slots[i]:GetTop()
        if type(a) == "number" and type(b) == "number" and math.abs(a - b) < 1 then multi = true end
    end
    if below and not multi then mode = "below"; return end
    for _, fs in ipairs(rgText) do fs:Hide() end
    if multi or not first then mode = "below"; return end   -- sous les composants malgré tout
    mode = "side"
    for _, l in ipairs(panel.lines) do if l.short then l.a:SetText(l.short) end end   -- colonne étroite : libellés courts
    panel:ClearAllPoints()
    panel:SetPoint("TOPLEFT", first, "TOPRIGHT", 6, -4)
    panel:SetPoint("RIGHT", form, "RIGHT", -20, 0)
end

local function UpdateForm(form, recipeInfo)
    if type(form) ~= "table" then return end
    if not panel then Build(form) end
    local id = type(recipeInfo) == "table" and recipeInfo.recipeID or nil
    if not id and recipeInfo == nil then
        id = lastId
        if not id and type(form.GetRecipeInfo) == "function" then
            local ok, ri = pcall(form.GetRecipeInfo, form)
            id = ok and type(ri) == "table" and ri.recipeID or nil
        end
    end
    lastId = id
    for _, fs in ipairs(rgText) do fs:Hide() end
    local e = id and On() and FC:CraftEconomics(id, IsEnchanter())
    if not e or (#e.parts == 0 and not e.out) then panel.e = nil; panel:Hide(); return end
    panel.e = e
    -- Prix de chaque composant (pour la quantité demandée), à droite de sa case
    local slots = BasicSlots(form)
    for i, slot in ipairs(slots) do
        local item, n = SlotReagent(slot, i, e)
        local p, src
        if item then p, src = BuyPrice(item) end
        local fs = rgText[i]
        if not fs then fs = holder:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); fs:SetJustifyH("LEFT"); rgText[i] = fs end
        fs:ClearAllPoints()
        fs:SetPoint("LEFT", slot, "RIGHT", 2, 0)
        fs:SetText(p and (API.Money(p * (n or 1), true) .. GRAY .. " " .. SourceTag(src) .. "|r") or (GRAY .. "no price|r"))
        fs:Show()
    end
    -- Bloc : composants, vente à l'HV, bénéfice ; enchanteur : désenchantement
    local k = 0
    local function Add(a, short, b)
        k = k + 1
        local l = Line(k)
        l.short = short
        l.a:SetText(a); l.b:SetText(b); l.a:Show(); l.b:Show()
    end
    if #e.parts > 0 then
        Add("Reagents", nil, (e.cost > 0 and API.Money(e.cost, true) or "") .. (e.missing > 0 and (GRAY .. " (" .. e.missing .. " without price)|r") or ""))
    end
    if e.out then
        Add("Sells at the AH" .. QtyText(e), "AH sale" .. QtyText(e), e.value and (API.Money(e.value, true) .. (e.valueEst and (GRAY .. " est.|r") or "")) or (GRAY .. "no price yet|r"))
        if e.profit then Add("Profit", nil, Signed(e.profit) .. Unsure(e)) end
        if e.de then
            Add("Disenchant" .. QtyText(e), nil, "~" .. API.Money(e.de, true) .. (e.deMissing > 0 and (GRAY .. " ?|r") or ""))
            Add("Profit if disenchanted", "Profit (DE)", Signed(e.deProfit) .. ((e.missing > 0 or e.est or e.deMissing > 0) and (GRAY .. " ?|r") or ""))
        end
    end
    for i = k + 1, #panel.lines do panel.lines[i].a:Hide(); panel.lines[i].b:Hide() end
    panel:SetHeight(math.max(1, k) * LINE_H)
    panel:ClearAllPoints()
    local last = slots[#slots]
    if last then panel:SetPoint("TOPLEFT", last, "BOTTOMLEFT", 0, -8)
    elseif form.Reagents then panel:SetPoint("TOPLEFT", form.Reagents, "TOPLEFT", 0, -24)
    else panel:SetPoint("TOPLEFT", form, "TOPLEFT", 28, -110) end
    panel:SetWidth(BLOCK_W)
    mode = "below"
    panel:Show()
    -- Positions connues une fois la fenêtre mise en page : place vérifiée juste après
    placeToken = placeToken + 1
    local tok = placeToken
    local function Check() if tok == placeToken and panel:IsShown() then Place(form, slots) end end
    if C_Timer and C_Timer.After then C_Timer.After(0, Check) else Check() end
end

-- ── Mise en place ────────────────────────────────────────────────────────
local function Parts()
    local pf = rawget(_G, "ProfessionsFrame")
    local cp = type(pf) == "table" and pf.CraftingPage
    if type(cp) ~= "table" then return pf end
    return pf, cp.RecipeList and cp.RecipeList.ScrollBox, cp.SchematicForm
end

-- Prix ou option changés : textes recalculés (lignes affichées et détail ouvert)
function FC:RefreshCraftProfit()
    gen = gen + 1
    local _, sb, form = Parts()
    EachListFrame(sb)
    if form and panel then UpdateForm(form, nil) end
end

local owner = {}
local setupDone = false
local function Setup()
    if setupDone then return end
    local pf, sb, form = Parts()
    if not (sb or form) then return end
    setupDone = true
    if sb then
        if ScrollUtil and ScrollUtil.AddInitializedFrameCallback then
            -- Ligne remplie par le jeu : nouvelle ligne (déjà suivie : notre suite de Init s'en est chargée)
            pcall(ScrollUtil.AddInitializedFrameCallback, sb, function(frame, node)
                if hookedBtn[frame] then return end
                HookButton(frame); Decorate(frame, node, true)
            end, owner, false)
        end
        if type(sb.Update) == "function" then hooksecurefunc(sb, "Update", function(self) EachListFrame(self) end) end
    end
    if form and type(form.Init) == "function" then
        hooksecurefunc(form, "Init", function(self, recipeInfo) UpdateForm(self, recipeInfo or false) end)
    end
    if pf and pf.HookScript then pf:HookScript("OnShow", function() FC:RefreshCraftProfit() end) end
end

-- Après un relevé de l'HV (et quand les options de l'HV changent) : prix de la fenêtre du jeu aussi
local prevRefresh = FC.RefreshProfessionPrices
function FC:RefreshProfessionPrices(...)
    if prevRefresh then prevRefresh(self, ...) end
    self:RefreshCraftProfit()
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(_, e, name)
    if e == "PLAYER_LOGIN" or name == "Blizzard_Professions" then Setup() end
end)

FC.CraftProfitInternals = { Setup = Setup, Deco = deco, RgText = rgText, Panel = function() return panel end,
    Mode = function() return mode end, IsEnchanter = IsEnchanter }   -- tests
