-- Forever Companion — CraftGuide.lua
-- Étape en cours du guide de leveling, dans une petite fenêtre collée en bas à droite de la fenêtre de métier du jeu
-- (ProfessionsFrame) : objet à fabriquer, fabrications restantes, barre de compétence de l'étape, composants
-- (possédés / nécessaires pour le reste de l'étape). Clic : la recette est ouverte dans la fenêtre du jeu.
-- Guide : celui de la fenêtre Professions de l'addon (données p.gd, Professions.lua).
-- Option : Options > Professions (prof_window_guide, cochée par défaut) ; la croix du panneau la décoche,
-- l'onglet « livre » en bas à droite de la fenêtre de métier l'affiche ou le cache.
-- Onglets de l'addon sur le bord droit de la fenêtre de métier : empilés à partir du bas (ceux du jeu partent du
-- haut) ; 1 = étape du guide (ici), 2 = désenchantement (Disenchant.lua).
local FC = ForeverCompanion
local API = ForeverCompanionAPI

local W = 236
local GOLD, GRAY, GREEN, RED = "|cffffd100", "|cff9d9d9d", "|cff40bf40", "|cffff5050"

local function On() return FC.db ~= nil and FC.db.global.prof_window_guide ~= false end
local function Say(msg) print("|cffffd700" .. FC.NAME .. "|r : " .. msg) end
local function HasTemplate(t)
    if not (C_XMLUtil and C_XMLUtil.GetTemplateInfo) then return false end
    local ok, info = pcall(C_XMLUtil.GetTemplateInfo, t)
    return ok and info ~= nil
end

-- ── Métier ouvert dans la fenêtre du jeu ─────────────────────────────────
-- → entrée de FC.Professions, compétence actuelle
local function OpenProfession()
    local T = C_TradeSkillUI
    local info
    if T and T.GetBaseProfessionInfo then
        local ok, v = pcall(T.GetBaseProfessionInfo); if ok and type(v) == "table" then info = v end
    end
    local pf = rawget(_G, "ProfessionsFrame")
    if not info and type(pf) == "table" and type(pf.GetProfessionInfo) == "function" then
        local ok, v = pcall(pf.GetProfessionInfo, pf); if ok and type(v) == "table" then info = v end
    end
    if type(info) ~= "table" then return nil end
    local ids = { info.professionID, info.parentProfessionID }
    for _, p in ipairs(FC.Professions or {}) do
        for _, id in ipairs(ids) do
            if id and p.sl == id then return p, tonumber(info.skillLevel) end
        end
    end
end

-- Ouvre la recette dans la fenêtre du jeu (liste à gauche, détail à droite)
local function OpenRecipe(recipeID)
    if not recipeID then return false end
    local T = C_TradeSkillUI
    local pf = rawget(_G, "ProfessionsFrame")
    local cp = type(pf) == "table" and pf.CraftingPage
    local list = type(cp) == "table" and cp.RecipeList
    local info
    if T and T.GetRecipeInfo then local ok, v = pcall(T.GetRecipeInfo, recipeID); if ok and type(v) == "table" then info = v end end
    if not info then return false end   -- recette absente de la liste du jeu (pas encore connue de ce client)
    if type(list) == "table" and type(list.SelectRecipe) == "function" and pcall(list.SelectRecipe, list, info, true) then
        return true, info
    end
    if T and T.OpenRecipe and pcall(T.OpenRecipe, recipeID) then return true, info end
    return false
end

-- ── Onglets en bas à droite de la fenêtre de métier ──────────────────────
local TAB_Y0 = 16            -- hauteur du premier onglet au-dessus du bas de la fenêtre
local sideTabs = {}          -- { order, tab } triés du bas vers le haut ; tab.want : à afficher
function FC:ProfessionSideTab(order)
    local pf = rawget(_G, "ProfessionsFrame")
    if type(pf) ~= "table" then return nil end
    local tab = API.CreateSideTab(pf)
    tab.want = false
    tab:Hide()
    sideTabs[#sideTabs + 1] = { order = order, tab = tab }
    table.sort(sideTabs, function(a, b) return a.order < b.order end)
    return tab
end
function FC:LayoutProfessionSideTabs()
    local pf = rawget(_G, "ProfessionsFrame")
    if type(pf) ~= "table" then return end
    local y = TAB_Y0
    for _, e in ipairs(sideTabs) do
        local t = e.tab
        t:ClearAllPoints()
        if t.want then
            t:SetPoint("BOTTOMLEFT", pf, "BOTTOMRIGHT", t.style == "forever" and -2 or 1, y)
            t:Show()
            y = y + (t.style == "forever" and 60 or 46)
        else
            t:Hide()
        end
    end
end

-- ── Panneau ──────────────────────────────────────────────────────────────
local panel, guideTab
local function ReagentButton(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(26, 26)
    b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetAllPoints(); b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    b.count = b:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
    b.count:SetPoint("TOP", b, "BOTTOM", 0, -1)
    b:SetScript("OnEnter", function(self)
        if not self.itemId then return end
        API.ShowItemTooltip(self, self.itemId, FC.CraftItems[self.itemId] or FC.LootItems[self.itemId])
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnClick", function(self, button)
        if self.itemId then API.ItemClick(self.itemId, FC.CraftItems[self.itemId] or FC.LootItems[self.itemId], button) end
    end)
    return b
end

local function Build(pf)
    local tpl = HasTemplate("TooltipBackdropTemplate") and "TooltipBackdropTemplate" or "BackdropTemplate"
    panel = CreateFrame("Button", nil, pf, tpl)
    panel:SetSize(W, 130)
    panel:SetFrameStrata("HIGH")
    if tpl == "BackdropTemplate" and panel.SetBackdrop then
        panel:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } })
        panel:SetBackdropColor(0.06, 0.06, 0.08, 0.94)
        panel:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)
    end
    panel:RegisterForClicks("LeftButtonUp")
    -- Titre
    panel.title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    panel.title:SetPoint("TOPLEFT", 10, -9)
    panel.title:SetText("Leveling guide")
    panel.stepNo = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    panel.stepNo:SetPoint("LEFT", panel.title, "RIGHT", 6, 0)
    panel.close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    panel.close:SetSize(22, 22); panel.close:SetPoint("TOPRIGHT", 0, 0)
    panel.close:SetScript("OnClick", function()
        FC.db.global.prof_window_guide = false
        FC:RefreshCraftGuide()
        Say("leveling step hidden. The book tab at the bottom right of the profession window shows it again.")
    end)
    panel.close:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:AddLine("Hide")
        GameTooltip:AddLine("The book tab at the bottom right of the profession window shows it again.", 0.8, 0.8, 0.8, true); GameTooltip:Show()
    end)
    panel.close:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- Objet à fabriquer
    panel.icon = panel:CreateTexture(nil, "ARTWORK")
    panel.icon:SetSize(34, 34); panel.icon:SetPoint("TOPLEFT", 10, -28)
    panel.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    panel.name = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    panel.name:SetPoint("TOPLEFT", panel.icon, "TOPRIGHT", 8, -1); panel.name:SetPoint("RIGHT", panel, "RIGHT", -10, 0)
    panel.name:SetJustifyH("LEFT"); panel.name:SetWordWrap(false)
    panel.sub = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.sub:SetPoint("TOPLEFT", panel.name, "BOTTOMLEFT", 0, -3); panel.sub:SetPoint("RIGHT", panel, "RIGHT", -10, 0)
    panel.sub:SetJustifyH("LEFT"); panel.sub:SetWordWrap(false)
    -- Compétence dans l'étape
    panel.bar = CreateFrame("StatusBar", nil, panel)
    panel.bar:SetPoint("TOPLEFT", panel.icon, "BOTTOMLEFT", 0, -8); panel.bar:SetPoint("RIGHT", panel, "RIGHT", -10, 0)
    panel.bar:SetHeight(12)
    panel.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    panel.bar:SetStatusBarColor(0.25, 0.55, 0.95)
    panel.bar.bg = panel.bar:CreateTexture(nil, "BACKGROUND"); panel.bar.bg:SetAllPoints(); panel.bar.bg:SetColorTexture(0, 0, 0, 0.55)
    panel.bar.text = panel.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.bar.text:SetPoint("CENTER", 0, 0)
    -- Composants
    panel.reag = {}
    panel.note = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    panel.note:SetJustifyH("LEFT"); panel.note:SetPoint("RIGHT", panel, "RIGHT", -10, 0)
    panel.hl = panel:CreateTexture(nil, "HIGHLIGHT")
    panel.hl:SetPoint("TOPLEFT", 4, -24); panel.hl:SetPoint("BOTTOMRIGHT", -4, 4)
    panel.hl:SetColorTexture(1, 0.82, 0, 0.06)
    -- Clic : la recette dans la fenêtre du jeu
    panel:SetScript("OnClick", function(self)
        if not self.recipe then return end
        local where = (self.src and self.src ~= "") and (" (" .. self.src .. ")") or ""
        local ok, info = OpenRecipe(self.recipe)
        if not ok then Say("this recipe isn't in your list yet" .. where .. ".")
        elseif info and info.learned == false then Say("you haven't learned this recipe yet" .. where .. ".") end
    end)
    panel:SetScript("OnEnter", function(self)
        if not self.st then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(self.st.n or "?", 1, 1, 1)
        GameTooltip:AddLine("Skill " .. (self.st.f or 0) .. " to " .. (self.st.t or 0), 0.8, 0.8, 0.8)
        if self.st.src and self.st.src ~= "" then GameTooltip:AddLine(self.st.src, 0.8, 0.8, 0.8, true) end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Click: show this recipe in the profession window.", 0.25, 0.75, 0.25, true)
        GameTooltip:Show()
    end)
    panel:SetScript("OnLeave", function() GameTooltip:Hide() end)
    panel:Hide()
end

-- À droite des onglets, le bas aligné sur celui de la fenêtre de métier
local function Place()
    panel:ClearAllPoints()
    panel:SetPoint("BOTTOMLEFT", guideTab, "BOTTOMRIGHT", 2, -TAB_Y0)
end

local function BuildTab()
    guideTab = FC:ProfessionSideTab(1)
    guideTab:SetIcon("inv_misc_book_11")
    guideTab:SetScript("OnClick", function()
        FC.db.global.prof_window_guide = not On()
        FC:RefreshCraftGuide()
    end)
    guideTab:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Leveling step")
        GameTooltip:AddLine(On() and "Click: hide the current step of the leveling guide." or "Click: show the current step of the leveling guide.",
            0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    guideTab:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

local function Fill(p, rank)
    local idx, st, left = FC:GuideCurrent(p, rank)
    panel.st, panel.recipe, panel.src = st, st and st.r, st and st.src
    if not st then
        panel.stepNo:SetText("")
        panel.icon:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
        panel.name:SetText(GREEN .. "Guide complete|r")
        panel.sub:SetText(GRAY .. "Your skill: " .. (rank or "?") .. "|r")
        panel.bar:Hide()
        for _, b in ipairs(panel.reag) do b:Hide() end
        panel.note:Hide()
        panel:SetHeight(76)
        return
    end
    panel.stepNo:SetText("step " .. idx .. " / " .. #p.gd)
    -- Objet fabriqué (sinon icône du sort de la recette)
    local name, q, icon
    if st.it then
        name, _, q = API.GetItemInfo(st.it)
        icon = API.GetItemIcon(st.it)
        local d = FC.CraftItems[st.it]
        if not icon and d and d.ic then icon = API.IconPath(d.ic) end
        name = name or (d and d.n)
    end
    icon = icon or (st.r and API.GetSpellIcon(st.r)) or "Interface\\Icons\\INV_Misc_QuestionMark"
    panel.icon:SetTexture(icon)
    local r, g, b = API.GetItemQualityColor(q or 1)
    panel.name:SetText(string.format("|cff%02x%02x%02x", (r or 1) * 255, (g or 1) * 255, (b or 1) * 255) .. (st.n or name or "?") .. "|r")
    local sub = {}
    if (st.c or 0) > 0 then sub[#sub + 1] = GOLD .. "×" .. left .. "|r " .. (left < st.c and "left" or "to craft") end
    sub[#sub + 1] = GRAY .. "skill " .. (st.f or 0) .. " - " .. (st.t or 0) .. "|r"
    panel.sub:SetText(table.concat(sub, "  ·  "))
    -- Barre : compétence entre le début et la fin de l'étape
    local lo, hi = st.f or 0, math.max((st.t or 0), (st.f or 0) + 1)
    panel.bar:SetMinMaxValues(lo, hi)
    panel.bar:SetValue(math.max(lo, math.min(hi, rank or lo)))
    panel.bar.text:SetText((rank or "?") .. " / " .. (st.t or "?"))
    panel.bar:Show()
    -- Composants pour le reste de l'étape : possédés / nécessaires
    for _, btn in ipairs(panel.reag) do btn:Hide() end
    local n = 0
    for _, m in ipairs(st.m or {}) do
        local id = m[1] or 0
        local need = FC:GuideScale(m[2] or 1, st, left)
        if need > 0 then
            n = n + 1
            local btn = panel.reag[n] or ReagentButton(panel); panel.reag[n] = btn
            btn.itemId = id > 0 and id or nil
            local ic = id > 0 and API.GetItemIcon(id)
            if not ic and id > 0 then local d = FC.CraftItems[id] or FC.LootItems[id]; if d and d.ic then ic = API.IconPath(d.ic) end end
            btn.icon:SetTexture(ic or "Interface\\Icons\\INV_Misc_QuestionMark")
            local have = id > 0 and API.ItemCount(id) or 0
            btn.count:SetText((have >= need and GREEN or RED) .. have .. "|r" .. GRAY .. "/" .. need .. "|r")
            btn:ClearAllPoints()
            btn:SetPoint("TOPLEFT", panel.bar, "BOTTOMLEFT", (n - 1) * 44 + 6, -8)
            btn:Show()
        end
    end
    local notes = {}
    if st.st then notes[#notes + 1] = "Stop at " .. st.st end
    if st.lt then notes[#notes + 1] = "|cff66bbffKeep: used later|r" end
    local h = 28 + 34 + 8 + 12
    if n > 0 then h = h + 8 + 26 + 14 end
    if #notes > 0 then
        panel.note:ClearAllPoints()
        panel.note:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, -(h + 4))
        panel.note:SetPoint("RIGHT", panel, "RIGHT", -10, 0)
        panel.note:SetText(table.concat(notes, "  ·  "))
        panel.note:Show()
        h = h + 16
    else
        panel.note:Hide()
    end
    panel:SetHeight(h + 10)
end

function FC:RefreshCraftGuide()
    local pf = rawget(_G, "ProfessionsFrame")
    if type(pf) ~= "table" then return end
    if not panel then Build(pf); BuildTab() end
    local p, rank
    if pf:IsShown() then p, rank = OpenProfession() end
    local has = (p and p.gd and #p.gd > 0) and true or false
    guideTab.want = has
    guideTab:SetActive(has and On())
    FC:LayoutProfessionSideTabs()
    if not (has and On()) then panel:Hide(); return end
    Place()
    Fill(p, rank)
    panel:Show()
end

-- ── Mise en place et mises à jour ────────────────────────────────────────
local queued = false
local function Queue()
    if queued then return end
    queued = true
    local function run() queued = false; FC:RefreshCraftGuide() end
    if C_Timer and C_Timer.After then C_Timer.After(0.1, run) else run() end
end

local hooked = false
local function Setup()
    local pf = rawget(_G, "ProfessionsFrame")
    if hooked or type(pf) ~= "table" or not pf.HookScript then return end
    hooked = true
    pf:HookScript("OnShow", Queue)
    pf:HookScript("OnHide", function() if panel then panel:Hide() end end)
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "SKILL_LINES_CHANGED",
    "BAG_UPDATE_DELAYED", "CHAT_MSG_SKILL", "NEW_RECIPE_LEARNED" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, name)
    if e == "ADDON_LOADED" then if name == "Blizzard_Professions" then Setup() end; return end
    if e == "PLAYER_LOGIN" then Setup(); return end
    Setup()
    local pf = rawget(_G, "ProfessionsFrame")
    if type(pf) == "table" and pf.IsShown and pf:IsShown() then Queue() end
end)

FC.CraftGuideInternals = { Panel = function() return panel end, Tab = function() return guideTab end, OpenProfession = OpenProfession,
    OpenRecipe = OpenRecipe, Setup = Setup }   -- tests
