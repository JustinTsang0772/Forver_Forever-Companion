-- Forever Companion — Disenchant.lua
-- Fenêtre de désenchantement : les objets des sacs à désenchanter, et un bouton qui désenchante le suivant.
--  · Pris : tous les objets verts, les bleus « lié quand équipé » pas encore liés ; violets seulement si le joueur
--    le coche (de_epic). Seulement ce qui se désenchante (armes, armures ; Auction.lua : DisenchantResults).
--  · Protégés (jamais pris) : objets de la liste BiS de la spé, améliorations d'après l'échelle active (Scales.lua),
--    objets ignorés par le joueur (clic droit ; de_ignore).
--  · L'HV paie mieux (prix relevé, après la taxe de 5 %, au-dessus de la valeur de désenchantement) : demande de
--    confirmation avant de le désenchanter, sauf si le joueur l'a désactivée (de_confirm_ah, « Ne plus demander »).
--  · Le jeu interdit à un addon de désenchanter seul : un clic (ou une touche) par objet, hors combat. Le bouton est
--    un bouton sécurisé du jeu (macro « /cast Désenchanter » + « /use sac case ») préparé sur l'objet suivant.
-- Ouverture : onglet en bas à droite de la fenêtre de métier d'Enchantement (au-dessus de celui du guide), ou /fc de.
local FC = ForeverCompanion
local API = ForeverCompanionAPI

local DISENCHANT, ENCHANTING = 13262, 333
local CUT = 0.95
local W, H = 380, 440
local ROW_H, ROWS = 26, 9
local GRAY, GREEN, RED, YELLOW = "|cff9d9d9d", "|cff40bf40", "|cffff5050", "|cffffd100"

local function G() return FC.db.global end
local function Say(msg) print("|cffffd700" .. FC.NAME .. "|r : " .. msg) end
local function InCombat() return InCombatLockdown and InCombatLockdown() end

-- ── Règles ───────────────────────────────────────────────────────────────
-- Compétence d'Enchantement (nil : métier non appris)
local function EnchantingRank()
    if not (GetProfessions and GetProfessionInfo) then return nil end
    local res = { pcall(GetProfessions) }
    if not res[1] then return nil end
    for i = 2, 6 do
        local idx = res[i]
        if idx then
            local ok, _, _, rank, _, _, _, sl = pcall(GetProfessionInfo, idx)
            if ok and sl == ENCHANTING then return tonumber(rank) or 0 end
        end
    end
end

-- Compétence requise (règle de Classic d'après le niveau d'objet : 1 jusqu'au niveau 20, puis +25 tous les 5 niveaux).
-- Au-delà du niveau 60 la règle n'est pas sûre pour Forever : 225 ; si le jeu refuse, l'objet est mis de côté.
local function RequiredSkill(ilvl)
    ilvl = tonumber(ilvl) or 0
    if ilvl <= 20 then return 1 end
    return math.min(225, math.floor((ilvl - 21) / 5) * 25 + 25)
end

-- Pris selon la qualité et la liaison : verts ; bleus « lié quand équipé » pas encore liés ; violets sur option
local function Eligible(quality, bindType, bound)
    if quality == 2 then return true end
    if quality == 3 then return bindType == 2 and not bound end
    if quality == 4 then return G().de_epic == true end
    return false
end

-- ── Objets des sacs ──────────────────────────────────────────────────────
local function NumSlots(bag)
    local fn = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
    if not fn then return 0 end
    local ok, n = pcall(fn, bag)
    return ok and tonumber(n) or 0
end
local function SlotItem(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local ok, i = pcall(C_Container.GetContainerItemInfo, bag, slot)
        if ok and type(i) == "table" and i.itemID then return i.itemID, i.hyperlink, i.isBound end
        return nil
    end
    if GetContainerItemInfo then
        local _, _, _, _, _, _, link, _, _, id, bound = GetContainerItemInfo(bag, slot)
        return id, link, bound
    end
end
local function ItemLevel(link, fallback)
    local fn = (C_Item and C_Item.GetDetailedItemLevelInfo) or GetDetailedItemLevelInfo
    if fn then local ok, v = pcall(fn, link); if ok and tonumber(v) then return tonumber(v) end end
    return fallback
end

local skipped = {}     -- [objet] = raison : mis de côté pour la session (« Passer », ou le jeu a refusé)
local S = { items = {}, low = {}, protected = {}, waiting = false }
local pick             -- { key = « sac:case », id } : objet choisi par le joueur pour passer en premier

-- Parcourt les sacs : S.items (à désenchanter, dans l'ordre), S.low (compétence trop basse), S.protected
local function Scan()
    local items, low, prot = {}, {}, {}
    local rank = EnchantingRank()
    local ignore = G().de_ignore or {}
    local Scales = FC.Scales
    S.waiting = false
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        for slot = 1, NumSlots(bag) do
            local id, link, bound = SlotItem(bag, slot)
            if id and link then
                local name, _, q, ilvl, _, _, _, _, _, icon, _, classID, _, bindType = API.GetItemInfo(link)
                if not name then
                    S.waiting = true
                elseif (classID == 2 or classID == 4) and Eligible(q, bindType, bound) and FC:DisenchantResults(id) then
                    ilvl = ItemLevel(link, ilvl)
                    local e = { key = bag .. ":" .. slot, bag = bag, slot = slot, id = id, link = link, name = name, q = q,
                        ilvl = ilvl, icon = icon, bound = bound, req = RequiredSkill(ilvl) }
                    e.value = FC.DisenchantValue and FC:DisenchantValue(id) or nil
                    local p, src
                    if FC.GetItemPrice then p, src = FC:GetItemPrice(id) end
                    if p and src == "ah" then
                        e.ah = math.floor(p * CUT + 0.5)
                        e.ahBetter = e.ah > (e.value or 0)
                    end
                    local why
                    if ignore[id] then why = "ignored"
                    elseif Scales and Scales.BisRank and Scales.BisRank(id) then why = "On your BiS list"
                    elseif Scales and Scales.Evaluate then
                        local ev, wait = Scales.Evaluate(link)
                        if type(ev) == "table" and ev.upgrade then why = "Upgrade for you"
                        elseif ev == nil and wait then why = "wait" end   -- objet pas encore lu : on ne le propose pas
                    end
                    if why == "wait" then
                        S.waiting = true
                    elseif why then
                        if why ~= "ignored" then e.why = why; prot[#prot + 1] = e end
                    elseif skipped[id] then
                        -- mis de côté pour la session
                    elseif rank and e.req > rank then
                        low[#low + 1] = e
                    else
                        items[#items + 1] = e
                    end
                end
            end
        end
    end
    table.sort(items, function(a, b)
        if a.q ~= b.q then return a.q < b.q end
        if (a.ilvl or 0) ~= (b.ilvl or 0) then return (a.ilvl or 0) < (b.ilvl or 0) end
        if a.bag ~= b.bag then return a.bag < b.bag end
        return a.slot < b.slot
    end)
    if pick then
        local found
        for i, e in ipairs(items) do
            if e.key == pick.key and e.id == pick.id then table.remove(items, i); table.insert(items, 1, e); found = true; break end
        end
        if not found then pick = nil end
    end
    S.items, S.low, S.protected, S.rank = items, low, prot, rank
    local n = 0
    for _ in pairs(ignore) do n = n + 1 end
    S.ignored = n
    return items
end

local function NeedsConfirm(e) return e and e.ahBetter and G().de_confirm_ah ~= false end
local function Macro(e)
    return "/cast " .. (API.GetSpellName(DISENCHANT) or "Disenchant") .. "\n/use " .. e.bag .. " " .. e.slot
end

-- ── Fenêtre ──────────────────────────────────────────────────────────────
local f, confirm
local tab          -- onglet de la fenêtre de métier d'Enchantement
local pendingArm = false
local lastCast        -- { id, name, t } : dernier clic sur un bouton armé (pour les refus du jeu)

-- Bouton sécurisé : prépare (ou retire) le désenchantement d'un objet ; seulement hors combat
local function Arm(btn, e)
    if InCombat() then pendingArm = true; return false end
    if e then
        btn:SetAttribute("type", "macro")
        btn:SetAttribute("macrotext", Macro(e))
    else
        btn:SetAttribute("type", nil)
        btn:SetAttribute("macrotext", nil)
    end
    btn.target = e
    return true
end

local function Money(c) return API.Money(c or 0, true) end

local function ItemTooltip(owner, e, hint)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    if GameTooltip.SetBagItem then pcall(GameTooltip.SetBagItem, GameTooltip, e.bag, e.slot)
    elseif GameTooltip.SetHyperlink then pcall(GameTooltip.SetHyperlink, GameTooltip, e.link) end
    GameTooltip:AddLine(" ")
    GameTooltip:AddDoubleLine("Disenchant", e.value and e.value > 0 and ("~" .. Money(e.value)) or (GRAY .. "?|r"), 1, 0.82, 0, 1, 1, 1)
    if e.ah then GameTooltip:AddDoubleLine("Auction House (after the 5% cut)", Money(e.ah), 1, 0.82, 0, 1, 1, 1) end
    if e.why then GameTooltip:AddLine("Protected: " .. e.why, 1, 0.31, 0.31) end
    if hint then for _, l in ipairs(hint) do GameTooltip:AddLine(l, 0.6, 0.6, 0.6, true) end end
    GameTooltip:Show()
end

local Refresh   -- plus bas
local retries = 0

local function ShowConfirm(e)
    if not confirm or InCombat() then return end
    confirm.e = e
    confirm.text:SetText(string.format("%s sells for %s at the Auction House (after the 5%% cut), but disenchants for about %s.\n\nDisenchant it anyway?",
        e.link or e.name, Money(e.ah), Money(e.value or 0)))
    confirm.never:SetChecked(false)
    Arm(confirm.yes, e)
    confirm:Show()
end

local function BuildConfirm()
    confirm = API.CreateWindow("ForeverCompanionDisenchantConfirm", UIParent, 360, 170)
    confirm:SetFrameStrata("DIALOG")
    confirm:SetPoint("CENTER", 0, 120)
    API.WindowTitle(confirm):SetText("The Auction House pays more")
    confirm.text = confirm:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    confirm.text:SetPoint("TOPLEFT", 18, -34); confirm.text:SetPoint("TOPRIGHT", -18, -34)
    confirm.text:SetJustifyH("LEFT")
    confirm.yes = CreateFrame("Button", "ForeverCompanionDisenchantConfirmYes", confirm, "SecureActionButtonTemplate, UIPanelButtonTemplate")
    confirm.yes:SetSize(130, 24); confirm.yes:SetPoint("BOTTOMLEFT", 18, 40)
    confirm.yes:SetText("Disenchant")
    confirm.yes:RegisterForClicks("AnyUp", "AnyDown")
    confirm.yes:SetScript("PostClick", function(self, _, down)
        if down then return end
        if confirm.never:GetChecked() then G().de_confirm_ah = false end
        if self.target then lastCast = { id = self.target.id, name = self.target.name, t = GetTime and GetTime() or 0 } end
        if not InCombat() then confirm:Hide() end
    end)
    confirm.skip = API.CreateMenuButton(confirm, 130, 24, "Skip this one")
    confirm.skip:SetPoint("BOTTOMRIGHT", -18, 40)
    confirm.skip:SetScript("OnClick", function()
        if confirm.never:GetChecked() then G().de_confirm_ah = false end
        if confirm.e then skipped[confirm.e.id] = "skipped" end
        if not InCombat() then confirm:Hide() end
        Refresh()
    end)
    confirm.never = CreateFrame("CheckButton", nil, confirm, "UICheckButtonTemplate")
    confirm.never:SetSize(22, 22); confirm.never:SetPoint("BOTTOMLEFT", 16, 12)
    confirm.never.label = confirm.never:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    confirm.never.label:SetPoint("LEFT", confirm.never, "RIGHT", 2, 1)
    confirm.never.label:SetText("Don't ask again (Options > Professions to undo)")
    if type(confirm.CloseButton) == "table" then
        confirm.CloseButton:SetScript("OnClick", function() if not InCombat() then confirm:Hide() end end)
    end
    confirm:Hide()
end

local function Row(parent, i)
    local r = CreateFrame("Button", nil, parent)
    r:SetHeight(ROW_H)
    r:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H); r:SetPoint("RIGHT", parent, "RIGHT", 0, 0)
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    r.bgL, r.bgR = API.RowBackground(r, i)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(20, 20); r.icon:SetPoint("LEFT", 6, 0); r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0); r.name:SetWidth(190); r.name:SetJustifyH("LEFT"); r.name:SetWordWrap(false)
    r.val = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.val:SetPoint("RIGHT", -6, 0); r.val:SetJustifyH("RIGHT")
    r.hl = r:CreateTexture(nil, "HIGHLIGHT"); r.hl:SetAllPoints(); r.hl:SetColorTexture(1, 1, 1, 0.06)
    r:SetScript("OnEnter", function(self)
        if not self.e then return end
        local hint = { self.low and (RED .. "Needs Enchanting " .. self.e.req .. ".|r") or "Left-click: disenchant this one next.",
            "Right-click: never disenchant this item (Options > Professions to reset)." }
        ItemTooltip(self, self.e, hint)
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    r:SetScript("OnClick", function(self, button)
        local e = self.e
        if not e then return end
        if button == "RightButton" then
            G().de_ignore = G().de_ignore or {}
            G().de_ignore[e.id] = true
            Say((e.link or e.name) .. " won't be disenchanted any more (Options > Professions to reset).")
        elseif not self.low then
            pick = { key = e.key, id = e.id }
        end
        Refresh()
    end)
    return r
end

local function QualityHex(q)
    local r, g, b = API.GetItemQualityColor(q or 1)
    return string.format("|cff%02x%02x%02x", (r or 1) * 255, (g or 1) * 255, (b or 1) * 255)
end

local function Build()
    f = API.CreateWindow("ForeverCompanionDisenchantFrame", UIParent, W, H)
    f:SetPoint("CENTER", 300, 60)
    f:SetFrameStrata("HIGH")
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) if not InCombat() then self:StartMoving() end end)
    f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); self.moved = true end)
    API.WindowTitle(f):SetText("Disenchant")
    if type(f.CloseButton) == "table" then
        f.CloseButton:SetScript("OnClick", function() if InCombat() then Say("not during combat.") else f:Hide() end end)
    end
    -- Bouton principal (sécurisé) : désenchante l'objet suivant
    local b = CreateFrame("Button", "ForeverCompanionDisenchantButton", f, "SecureActionButtonTemplate")
    b:SetPoint("TOPLEFT", 14, -32); b:SetPoint("TOPRIGHT", -14, -32); b:SetHeight(52)
    b:RegisterForClicks("AnyUp", "AnyDown")
    b.bg = b:CreateTexture(nil, "BACKGROUND"); b.bg:SetAllPoints(); b.bg:SetColorTexture(0.12, 0.10, 0.06, 0.9)
    b.border = b:CreateTexture(nil, "BORDER"); b.border:SetPoint("TOPLEFT", -1, 1); b.border:SetPoint("BOTTOMRIGHT", 1, -1)
    b.border:SetColorTexture(0.55, 0.45, 0.2, 0.9)
    b.bg:SetDrawLayer("BACKGROUND", 1); b.border:SetDrawLayer("BACKGROUND", 0)
    b.hl = b:CreateTexture(nil, "HIGHLIGHT"); b.hl:SetAllPoints(); b.hl:SetColorTexture(1, 0.82, 0, 0.12)
    b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetSize(40, 40); b.icon:SetPoint("LEFT", 6, 0)
    b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    b.title = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    b.title:SetPoint("TOPLEFT", b.icon, "TOPRIGHT", 10, -2); b.title:SetPoint("RIGHT", b, "RIGHT", -8, 0); b.title:SetJustifyH("LEFT")
    b.name = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.name:SetPoint("TOPLEFT", b.title, "BOTTOMLEFT", 0, -4); b.name:SetPoint("RIGHT", b, "RIGHT", -8, 0)
    b.name:SetJustifyH("LEFT"); b.name:SetWordWrap(false)
    b:SetScript("PostClick", function(self, _, down)
        if down then return end
        local e = S.next
        if not e then return end
        if NeedsConfirm(e) then ShowConfirm(e)
        elseif self.target then lastCast = { id = self.target.id, name = self.target.name, t = GetTime and GetTime() or 0 } end
    end)
    b:SetScript("OnEnter", function(self) if S.next then ItemTooltip(self, S.next, { "One click per item: the game doesn't let an addon disenchant on its own." }) end end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    f.button = b
    -- Résumé
    f.summary = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.summary:SetPoint("TOPLEFT", b, "BOTTOMLEFT", 0, -8); f.summary:SetPoint("RIGHT", f, "RIGHT", -14, 0); f.summary:SetJustifyH("LEFT")
    -- Liste
    f.list = CreateFrame("Frame", nil, f)
    f.list:SetPoint("TOPLEFT", f.summary, "BOTTOMLEFT", 0, -6); f.list:SetPoint("RIGHT", f, "RIGHT", -14, 0)
    f.list:SetHeight(ROWS * ROW_H)
    f.list:EnableMouseWheel(true)
    f.offset = 0
    f.list:SetScript("OnMouseWheel", function(_, d)
        f.offset = math.max(0, f.offset - d)
        Refresh()
    end)
    f.rows = {}
    for i = 1, ROWS do f.rows[i] = Row(f.list, i) end
    f.more = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.more:SetPoint("TOPRIGHT", f.list, "BOTTOMRIGHT", 0, -2)
    -- Protégés, ignorés
    f.prot = CreateFrame("Button", nil, f)
    f.prot:SetPoint("TOPLEFT", f.list, "BOTTOMLEFT", 0, -16); f.prot:SetSize(W - 28, 16)
    f.prot.text = f.prot:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.prot.text:SetPoint("LEFT"); f.prot.text:SetJustifyH("LEFT")
    f.prot:SetScript("OnEnter", function(self)
        if #S.protected == 0 then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Never disenchanted here", 1, 0.82, 0)
        for _, e in ipairs(S.protected) do GameTooltip:AddDoubleLine(QualityHex(e.q) .. e.name .. "|r", e.why, 1, 1, 1, 0.8, 0.8, 0.8) end
        GameTooltip:Show()
    end)
    f.prot:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- Options
    local function Opt(y, label, get, set)
        local cb = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
        cb:SetSize(22, 22); cb:SetPoint("BOTTOMLEFT", 12, y)
        cb.label = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        cb.label:SetPoint("LEFT", cb, "RIGHT", 2, 1); cb.label:SetText(label)
        cb:SetHitRectInsets(0, -((cb.label:GetStringWidth() or 200) + 4), 0, 0)
        cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false); Refresh() end)
        cb.get = get
        return cb
    end
    f.optEpic = Opt(36, "Epic (purple) items too", function() return G().de_epic == true end, function(v) G().de_epic = v end)
    f.optAsk = Opt(14, "Ask first when the Auction House pays more", function() return G().de_confirm_ah ~= false end, function(v) G().de_confirm_ah = v end)
    f.combat = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.combat:SetPoint("BOTTOMRIGHT", -16, 20); f.combat:SetText(RED .. "In combat|r"); f.combat:Hide()
    f:SetScript("OnShow", function() Refresh(); if tab then tab:SetActive(true) end end)
    f:HookScript("OnHide", function() if tab then tab:SetActive(false) end end)
    f:Hide()
    BuildConfirm()
end

Refresh = function()
    if not f or not f:IsShown() then return end
    Scan()
    local items = S.items
    S.next = items[1]
    local b = f.button
    -- Bouton principal (ses attributs ne changent pas en combat : on le met à jour à la sortie du combat)
    if InCombat() then
        pendingArm = true
    elseif S.rank == nil then
        b.icon:SetTexture(API.GetSpellIcon(DISENCHANT) or "Interface\\Icons\\INV_Enchant_Disenchant")
        b.title:SetText(GRAY .. "You don't know Enchanting|r"); b.name:SetText("")
        Arm(b, nil)
    elseif not S.next then
        b.icon:SetTexture(API.GetSpellIcon(DISENCHANT) or "Interface\\Icons\\INV_Enchant_Disenchant")
        b.title:SetText(GRAY .. "Nothing to disenchant|r"); b.name:SetText(S.waiting and (GRAY .. "Reading your bags…|r") or "")
        Arm(b, nil)
    else
        local e = S.next
        b.icon:SetTexture(e.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
        b.title:SetText(NeedsConfirm(e) and (YELLOW .. "Click: the Auction House pays more, confirm first|r") or "Click to disenchant")
        b.name:SetText(QualityHex(e.q) .. e.name .. "|r" .. GRAY .. "  ilvl " .. (e.ilvl or "?") .. "|r"
            .. (e.value and e.value > 0 and ("  ~" .. Money(e.value)) or ""))
        Arm(b, (not NeedsConfirm(e)) and e or nil)
    end
    -- Résumé
    local total = 0
    for _, e in ipairs(items) do total = total + (e.value or 0) end
    f.summary:SetText(#items .. " item(s) to disenchant" .. (total > 0 and ("  ·  materials worth ~" .. Money(total)) or "")
        .. (#S.low > 0 and (GRAY .. "  ·  " .. #S.low .. " need more skill|r") or ""))
    -- Liste : à désenchanter, puis compétence trop basse
    local all = {}
    for _, e in ipairs(items) do all[#all + 1] = { e = e } end
    for _, e in ipairs(S.low) do all[#all + 1] = { e = e, low = true } end
    f.offset = math.max(0, math.min(f.offset, #all - ROWS))
    for i, r in ipairs(f.rows) do
        local d = all[f.offset + i]
        r.e, r.low = d and d.e, d and d.low
        if d then
            local e = d.e
            r.icon:SetTexture(e.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
            r.icon:SetDesaturated(d.low and true or false)
            r.name:SetText((d.low and GRAY or QualityHex(e.q)) .. e.name .. "|r" .. GRAY .. "  " .. (e.ilvl or "") .. "|r")
            local v
            if d.low then v = RED .. "needs " .. e.req .. "|r"
            elseif e.ahBetter then v = YELLOW .. "AH " .. Money(e.ah) .. "|r" .. GRAY .. "  ~" .. Money(e.value or 0) .. "|r"
            else v = e.value and e.value > 0 and ("~" .. Money(e.value)) or (GRAY .. "?|r") end
            r.val:SetText(v)
            r:Show()
        else
            r:Hide()
        end
    end
    local below = #all - f.offset - ROWS
    f.more:SetText(below > 0 and (GRAY .. below .. " more (mouse wheel)|r") or "")
    local parts = {}
    if #S.protected > 0 then parts[#parts + 1] = #S.protected .. " protected (BiS list, upgrades)" end
    if (S.ignored or 0) > 0 then parts[#parts + 1] = S.ignored .. " ignored" end
    f.prot.text:SetText(#parts > 0 and (GRAY .. table.concat(parts, "  ·  ") .. "|r") or "")
    f.optEpic:SetChecked(f.optEpic.get()); f.optAsk:SetChecked(f.optAsk.get())
    f.combat:SetShown(InCombat() and true or false)
    -- Objets pas encore chargés par le client : nouvel essai un peu plus tard (5 au plus)
    if not S.waiting then retries = 0
    elseif retries < 5 and C_Timer and C_Timer.After then
        retries = retries + 1
        C_Timer.After(1, function() if f:IsShown() then Refresh() end end)
    end
end

function FC:RefreshDisenchant() if Refresh then Refresh() end end

function FC:ToggleDisenchant(anchor)
    if not f then Build() end
    if InCombat() then Say("not during combat."); return end
    if f:IsShown() then f:Hide(); return end
    -- À côté de la fenêtre de métier, après ses onglets (sauf si le joueur l'a déplacée)
    if anchor and not f.moved then f:ClearAllPoints(); f:SetPoint("TOPLEFT", anchor, "TOPRIGHT", 80, 0) end
    f:Show()
    Refresh()
end

-- Options : remettre les objets ignorés (et ceux mis de côté pour la session)
function FC:ResetDisenchantIgnored()
    G().de_ignore = {}
    for k in pairs(skipped) do skipped[k] = nil end
    if Refresh then Refresh() end
end
function FC:DisenchantIgnoredCount()
    local n = 0
    for _ in pairs(G().de_ignore or {}) do n = n + 1 end
    return n
end

-- ── Onglet dans la fenêtre de métier d'Enchantement ──────────────────────
local function OpenProfessionID()
    local T = C_TradeSkillUI
    if T and T.GetBaseProfessionInfo then
        local ok, v = pcall(T.GetBaseProfessionInfo)
        if ok and type(v) == "table" then return v.professionID, v.parentProfessionID end
    end
end
local function UpdateTab()
    local pf = rawget(_G, "ProfessionsFrame")
    if type(pf) ~= "table" then return end
    if not tab then
        tab = FC.ProfessionSideTab and FC:ProfessionSideTab(2)
        if not tab then return end
        tab:SetIcon(API.GetSpellIcon(DISENCHANT) or "INV_Enchant_Disenchant")
        tab:SetActive(f ~= nil and f:IsShown())
        tab:SetScript("OnClick", function() FC:ToggleDisenchant(pf) end)
        tab:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine("Disenchant")
            GameTooltip:AddLine("Your green items and unbound blue \"Binds when equipped\" items, one click per item. Never your BiS items or upgrades.", 0.8, 0.8, 0.8, true)
            GameTooltip:Show()
        end)
        tab:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    local id, parent = OpenProfessionID()
    tab.want = (pf:IsShown() and (id == ENCHANTING or parent == ENCHANTING)) and true or false
    FC:LayoutProfessionSideTabs()
end

-- ── Évènements ───────────────────────────────────────────────────────────
local queued = false
local function Queue()
    if queued then return end
    queued = true
    local function run() queued = false; Refresh() end
    if C_Timer and C_Timer.After then C_Timer.After(0.2, run) else run() end
end
local DE_ERRORS
local function IsDisenchantError(msg)
    if not DE_ERRORS then
        DE_ERRORS = {}
        for _, k in ipairs({ "SPELL_FAILED_CANT_BE_DISENCHANTED", "SPELL_FAILED_CANT_BE_DISENCHANTED_SKILL", "SPELL_FAILED_LOW_CASTLEVEL",
            "ERR_CANT_BE_DISENCHANTED" }) do
            local v = rawget(_G, k)
            if type(v) == "string" then DE_ERRORS[v] = true end
        end
    end
    return DE_ERRORS[msg] == true
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "BAG_UPDATE_DELAYED", "PLAYER_REGEN_ENABLED", "PLAYER_REGEN_DISABLED",
    "GET_ITEM_INFO_RECEIVED", "SKILL_LINES_CHANGED", "UI_ERROR_MESSAGE", "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, a1, a2)
    if e == "ADDON_LOADED" then
        if a1 == "Blizzard_Professions" then
            local pf = rawget(_G, "ProfessionsFrame")
            if type(pf) == "table" and pf.HookScript then
                pf:HookScript("OnShow", UpdateTab)
            end
        end
        return
    end
    if e == "TRADE_SKILL_SHOW" or e == "TRADE_SKILL_LIST_UPDATE" then UpdateTab(); return end
    if e == "UI_ERROR_MESSAGE" then
        local msg = type(a2) == "string" and a2 or a1
        local now = GetTime and GetTime() or 0
        if lastCast and now - lastCast.t < 3 and IsDisenchantError(msg) then
            skipped[lastCast.id] = msg
            Say((lastCast.name or "This item") .. ": " .. msg .. " Set aside for now.")
            lastCast = nil
            Queue()
        end
        return
    end
    if e == "PLAYER_REGEN_ENABLED" then pendingArm = false end
    if f and f:IsShown() then Queue() end
end)

FC.DisenchantInternals = { Scan = Scan, S = S, Eligible = Eligible, RequiredSkill = RequiredSkill, Macro = Macro,
    NeedsConfirm = NeedsConfirm, Frame = function() return f end, Confirm = function() return confirm end,
    Skipped = skipped, Refresh = function() Refresh() end, UpdateTab = UpdateTab, Tab = function() return tab end,
    IsDisenchantError = IsDisenchantError, SetLastCast = function(v) lastCast = v end }   -- tests
