-- Forever Companion — Auction.lua
-- Prix de l'hôtel des ventes : scan complet (bouton, et automatique à l'ouverture
-- si l'option est active), enregistrement des prix vus pendant les recherches,
-- historique quotidien, et lignes de prix dans les info-bulles.
--
-- Deux API possibles selon le client :
--  * moderne : C_AuctionHouse.ReplicateItems (scan complet), résultats de recherche
--    (AUCTION_HOUSE_BROWSE_RESULTS_*, COMMODITY_SEARCH_RESULTS_UPDATED) ;
--  * ancienne : QueryAuctionItems(getAll) et GetAuctionItemInfo.
-- Données : FC.db.factionrealm.ah.items[id] = {
--   m = prix unitaire minimum (achat immédiat, cuivre), q = quantité en vente,
--   t = date du dernier relevé, n = nom, a = moyenne des minimums quotidiens sur 7 jours,
--   h = historique "jour:prix:quantité,jour:prix,…" (jour = jour LOCAL du joueur, minuit à minuit, voir LocalDay ;
--       quantité en vente ce jour-là, d'après le dernier relevé complet du jour, absente si aucun relevé complet),
--   r = relevés détaillés d'aujourd'hui et d'hier "heure:prix:quantité,…" (un point par scan ; au-delà, seul h reste) }
local FC = ForeverCompanion
local API = ForeverCompanionAPI

local FULL_THROTTLE = 15 * 60     -- le jeu limite le scan complet à 1 toutes les 15 min
local ANSWER_WAIT = 180           -- secondes d'attente de la réponse au scan complet (le serveur peut être lent)
local CHUNK = 1000                -- enchères par image si le jeu ne permet pas de mesurer le temps
local FRAME_BUDGET = 8            -- millisecondes de travail par image (lecture et enregistrement du scan)
local AH = { state = nil }
FC.Auction = AH

local function Now() return time() end
-- Jour local du joueur (minuit à minuit à l'heure de son ordinateur, heure d'été comprise) :
-- un numéro par date du calendrier. L'historique est personnel, chaque joueur a donc ses propres jours.
local function LocalDay(t)
    local d = date("*t", t)
    return math.floor(time({ year = d.year, month = d.month, day = d.day, hour = 12 }) / 86400)
end
local function Today() return LocalDay(Now()) end
-- Début d'hier (minuit local) : les relevés détaillés plus anciens ne sont plus gardés
local function YesterdayStart(t)
    local d = date("*t", t)
    return time({ year = d.year, month = d.month, day = d.day - 1, hour = 0, min = 0, sec = 0 })
end
AH.LocalDay = LocalDay
local RECENT_GAP = 600   -- deux relevés détaillés à moins de 10 min : le second remplace le premier

-- ── Journal du scan (/fc ahlog) : chaque étape avec son heure, pour voir où un scan coince ──
local log = {}
local function Log(text)
    log[#log + 1] = { (debugprofilestop and debugprofilestop() or (Now() * 1000)), date("%H:%M:%S"), text }
    if #log > 40 then table.remove(log, 1) end
end
AH.Log = Log
function AH.PrintLog()
    print("|cffffd700" .. FC.NAME .. "|r : Auction House scan log (" .. #log .. " steps)")
    if #log == 0 then print("  nothing yet: open the Auction House first.") end
    local t0 = log[1] and log[1][1]
    for _, e in ipairs(log) do print(string.format("  %s  +%.1f s  %s", e[2], (e[1] - t0) / 1000, e[3])) end
end

local function DB() return FC.db and FC.db.factionrealm.ah end
local function Opt(k) return FC.db and FC.db.global[k] end

-- L'ancienne API d'abord : le client Classic Era possède aussi C_AuctionHouse.ReplicateItems,
-- mais son HV fonctionne avec QueryAuctionItems (le jeu actuel n'a plus que la nouvelle API).
function AH.API()
    if QueryAuctionItems and GetAuctionItemInfo then return "legacy" end
    if C_AuctionHouse and C_AuctionHouse.ReplicateItems and C_AuctionHouse.GetReplicateItemInfo then return "modern" end
    return nil
end

-- ── Historique ───────────────────────────────────────────────────────────
-- Relevés détaillés (r) : même format, avec l'heure (time()) à la place du jour
function AH.ParseRecent(r) return AH.ParseHistory(r) end
function AH.ParseHistory(h)
    local out = {}
    for d, p, q in tostring(h or ""):gmatch("(%d+):(%d+):?(%d*)") do
        table.insert(out, { tonumber(d), tonumber(p), q ~= "" and tonumber(q) or nil })
    end
    return out
end
local function WriteHistory(list)
    local parts = {}
    for _, e in ipairs(list) do parts[#parts + 1] = e[1] .. ":" .. e[2] .. (e[3] and (":" .. e[3]) or "") end
    return table.concat(parts, ",")
end

-- Met à jour une entrée avec un relevé (prix unitaire, quantité)
-- trusted = minimum réel de tout l'HV (scan complet, résultats de recherche du jeu actuel) ;
-- sinon (une page de résultats de l'ancienne API) on ne remonte pas un prix récent.
-- qtyOk = quantité complète (toutes les enchères de l'objet vues) : notée pour le jour (graphique).
local function Apply(items, id, unit, qty, name, now, today, keep, trusted, qtyOk, recentFrom)
    local e = items[id]
    if not e then e = {}; items[id] = e end
    if trusted or not e.m or (now - (e.t or 0)) > 3600 or unit < e.m then
        e.m, e.q = unit, qty
    end
    if qtyOk and qty then e.q = qty end
    e.t = now
    if name and name ~= "" then e.n = name end
    -- Minimum du jour + moyenne sur 7 jours
    local hist = AH.ParseHistory(e.h)
    local last = hist[#hist]
    local q = (qtyOk and qty) or nil
    if last and last[1] == today then
        last[2] = math.min(last[2], unit)
        if q then last[3] = q end   -- dernier relevé complet du jour
    else table.insert(hist, { today, unit, q }) end
    local cut = today - (keep or 60)
    local first = 1
    while hist[first] and hist[first][1] < cut do first = first + 1 end
    if first > 1 then local k = {}; for i = first, #hist do k[#k + 1] = hist[i] end; hist = k end
    local sum, n = 0, 0
    for _, x in ipairs(hist) do if x[1] > today - 7 then sum = sum + x[2]; n = n + 1 end end
    e.a = n > 0 and math.floor(sum / n + 0.5) or nil
    e.h = WriteHistory(hist)
    -- Relevés détaillés d'aujourd'hui et d'hier : un point par scan (minimum réel de l'HV seulement)
    if trusted then
        local rec = AH.ParseRecent(e.r)
        local lr = rec[#rec]
        if lr and now - lr[1] < RECENT_GAP then lr[1], lr[2] = now, unit; if q then lr[3] = q end
        else rec[#rec + 1] = { now, unit, q } end
        local k = {}
        for _, x in ipairs(rec) do if x[1] >= recentFrom then k[#k + 1] = x end end
        e.r = #k > 0 and WriteHistory(k) or nil
    end
end

-- Temps écoulé (ms) depuis t0 : sert à limiter le travail par image
local function Clock() return debugprofilestop and debugprofilestop() or nil end
local function Over(t0) return t0 and (debugprofilestop() - t0) > FRAME_BUDGET end
local function AfterCommit(n)
    if n > 0 then
        if FC.RefreshProfessionPrices then FC:RefreshProfessionPrices() end
        if FC.RefreshMarket then FC:RefreshMarket("prices") end
    end
end
-- Enregistrement d'un gros lot (scan complet) par tranches de quelques ms : pas de gel en fin de scan
function AH.CommitAsync(batch, trusted, onDone, onProgress)
    local db = DB()
    if not db then onDone(0); return end
    local ids = {}
    for id in pairs(batch) do ids[#ids + 1] = id end
    local now, today, keep = Now(), Today(), Opt("ah_keep_days") or 60
    local recentFrom = YesterdayStart(now)
    local i = 1
    local function step()
        local t0, done = Clock(), 0
        while i <= #ids do
            local id = ids[i]; local v = batch[id]
            Apply(db.items, id, v[1], v[2], v[3], now, today, keep, trusted, trusted, recentFrom)
            i = i + 1; done = done + 1
            if (t0 and Over(t0)) or (not t0 and done >= 500) then break end
        end
        if i > #ids then AfterCommit(#ids); onDone(#ids); return end
        if onProgress then onProgress(i - 1, #ids) end
        C_Timer.After(0, step)
    end
    step()
end

-- Enregistre un lot {[id] = {min, qty, name}} ; qtyOk (quantités complètes) : comme trusted par défaut
function AH.Commit(batch, trusted, qtyOk)
    local db = DB(); if not db then return 0 end
    local now, today, keep = Now(), Today(), Opt("ah_keep_days") or 60
    local recentFrom = YesterdayStart(now)
    if qtyOk == nil then qtyOk = trusted end
    local n = 0
    for id, v in pairs(batch) do
        Apply(db.items, id, v[1], v[2], v[3], now, today, keep, trusted, qtyOk, recentFrom)
        n = n + 1
    end
    AfterCommit(n)
    return n
end

local function Collect(batch, id, buyout, count, name)
    if not id or id <= 0 or not buyout or buyout <= 0 then return end
    local unit = math.floor(buyout / math.max(1, count or 1) + 0.5)
    local b = batch[id]
    if not b then batch[id] = { unit, count or 1, name }
    else
        if unit < b[1] then b[1] = unit end
        b[2] = b[2] + (count or 1)
        if name and not b[3] then b[3] = name end
    end
end

-- ── Prix pour le reste de l'addon ────────────────────────────────────────
-- Renvoie prix unitaire (cuivre), "ah" ou "site", date du relevé
function FC:GetItemPrice(id)
    local db = Opt("ah_enabled") ~= false and DB()
    local e = db and db.items[id]
    if e and e.m then return e.m, "ah", e.t end
    local d = FC.CraftItems and FC.CraftItems[id]
    if d and d.p then return d.p, "site" end
end
function FC:GetAuctionEntry(id) local db = DB(); return db and db.items[id] end

-- ── Prix des marchands : relevés à chaque ouverture d'un marchand (stock illimité, payé en or) ──
local function ReadMerchant()
    local g = FC.db and FC.db.global
    if not g or not GetMerchantNumItems then return 0 end
    g.vendor_prices = g.vendor_prices or {}
    local n = 0
    for i = 1, (GetMerchantNumItems() or 0) do
        local id = GetMerchantItemID and GetMerchantItemID(i)
        if not id then
            local link = GetMerchantItemLink and GetMerchantItemLink(i)
            id = link and tonumber(link:match("item:(%d+)"))
        end
        local price, qty, avail, ext
        if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
            local info = C_MerchantFrame.GetItemInfo(i)
            if info then price, qty, avail, ext = info.price, info.stackCount, info.numAvailable, info.hasExtendedCost end
        elseif GetMerchantItemInfo then
            local _
            _, _, price, qty, avail, _, _, ext = GetMerchantItemInfo(i)
        end
        if id and price and price > 0 and not ext and (avail == nil or avail < 0) then
            g.vendor_prices[id] = math.floor(price / math.max(1, qty or 1) + 0.5)
            n = n + 1
        end
    end
    return n
end
function FC:GetVendorPrice(id) local g = FC.db and FC.db.global.vendor_prices; return g and g[id] end
-- Prix d'achat le moins cher : marchand (relevé), sinon HV (relevé), sinon prix indicatif du site
-- renvoie prix, "vendor" / "ah" / "site", date du relevé de l'HV
function FC:GetBuyPrice(id)
    local v = self:GetVendorPrice(id)
    local a, src, t
    if self.GetItemPrice then a, src, t = self:GetItemPrice(id) end
    if v and (not a or v <= a) then return v, "vendor" end
    return a, src, t
end
local merchantEv = CreateFrame("Frame")
pcall(merchantEv.RegisterEvent, merchantEv, "MERCHANT_SHOW")
pcall(merchantEv.RegisterEvent, merchantEv, "MERCHANT_UPDATE")
merchantEv:SetScript("OnEvent", function() pcall(ReadMerchant) end)
AH.ReadMerchant = ReadMerchant   -- tests

function AH.Age(t)
    if not t then return "?" end
    local s = math.max(0, Now() - t)
    if s < 3600 then return math.max(1, math.floor(s / 60)) .. " min" end
    if s < 86400 then return math.floor(s / 3600) .. " h" end
    return math.floor(s / 86400) .. " d"
end

-- ── Scan complet ─────────────────────────────────────────────────────────
local ui   -- barre sous la fenêtre de l'HV
local events = CreateFrame("Frame")

function AH.CanFullScan()
    local api = AH.API()
    if not api then return false, "no auction API" end
    if not AH.open then return false, "open the Auction House" end
    if AH.state then return false, "scan in progress" end
    if api == "legacy" and CanSendAuctionQuery then
        local ok, all = CanSendAuctionQuery()
        if not all then return false, "full scan available later (game limit)" end
        return true
    end
    local db, G = DB() or {}, (FC.db and FC.db.global) or {}
    -- Dernière demande envoyée, réussie ou non : le serveur compte aussi celles restées sans réponse,
    -- et redemander trop tôt le bloque encore plus (limite du compte entier)
    local last = math.max(db.lastFull or 0, db.lastAttempt or 0, G.ahLastFull or 0, G.ahLastAttempt or 0)
    local wait = FULL_THROTTLE - (Now() - last)
    if wait > 0 then return false, "next full scan in " .. math.ceil(wait / 60) .. " min" end
    return true
end

local function Status(text)
    if ui and ui.status then ui.status:SetText(text or "") end
end

local function Finish(batch, auctions, started)
    local function done(n)
        local db = DB()
        if db then db.lastFullCount = n; db.lastFullAuctions = auctions; db.lastFull = Now() end
        if FC.db then FC.db.global.ahLastFull = Now() end
        AH.state = nil
        Log("prices saved: " .. n .. " items")
        local secs = (debugprofilestop and started) and ((debugprofilestop() - started) / 1000) or nil
        print(string.format("|cffffd700%s|r : Auction House scan — %d items, %d auctions%s.", FC.NAME, n, auctions,
            secs and string.format(" (%.1f s)", secs) or ""))
        AH.UpdateUI()
    end
    -- Enregistrement par tranches (l'état « en cours » reste posé jusqu'au bout)
    AH.CommitAsync(batch, true, done, function(k, total)
        Status(string.format("Saving prices… %d%%", math.floor(k * 100 / total)))
    end)
end

-- Traite les enchères par morceaux (une image = CHUNK enchères)
local function Process(total, getInfo, first)
    local batch, i = {}, first
    local last = first + total - 1
    local started = debugprofilestop and debugprofilestop()
    local function step()
        if not AH.state then return end
        if not AH.open then
            -- HV fermé en cours de route : les données restantes ne sont plus lisibles.
            -- Ce qui a été lu est gardé, sans remplacer un prix plus bas déjà connu.
            AH.Commit(batch, false); AH.state = nil; AH.UpdateUI()
            return
        end
        -- Quelques millisecondes par image (mesurées), sinon CHUNK enchères
        local t0, n = Clock(), 0
        while i <= last do
            local name, count, buyout, id = getInfo(i)
            Collect(batch, id, buyout, count, name)
            i = i + 1; n = n + 1
            if t0 then
                if n % 50 == 0 and Over(t0) then break end
            elseif n >= CHUNK then break end
        end
        if i > last then Finish(batch, total, started); return end
        Status(string.format("Scanning… %d%%", math.floor((i - first) * 100 / total)))
        C_Timer.After(0, step)
    end
    step()
end

local function ModernInfo(k)
    local name, _, count, _, _, _, _, _, _, buyout, _, _, _, _, _, _, id = C_AuctionHouse.GetReplicateItemInfo(k)
    return name, count, buyout, id
end
local function LegacyInfo(k)
    local name, _, count, _, _, _, _, _, _, buyout, _, _, _, _, _, _, id = GetAuctionItemInfo("list", k)
    return name, count, buyout, id
end

-- L'HV du jeu filtre ses demandes : envoyée pendant qu'il traite les siennes (ouverture, recherche),
-- une demande peut être écartée sans rien dire. On attend qu'il soit prêt, et on renvoie une fois si elle est écartée.
local function ThrottleBusy()
    if not (C_AuctionHouse and C_AuctionHouse.IsThrottledMessageSystemReady) then return false end
    local ok, ready = pcall(C_AuctionHouse.IsThrottledMessageSystemReady)
    return ok and ready == false
end
local SCAN_EVENTS = { "REPLICATE_ITEM_LIST_UPDATE", "AUCTION_HOUSE_THROTTLED_SYSTEM_READY", "AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED" }
local function StopListening()
    for _, e in ipairs(SCAN_EVENTS) do pcall(events.UnregisterEvent, events, e) end
end
-- Envoi (ou attente que l'HV soit prêt) ; renvoie false + erreur si l'envoi échoue
local SendFailed
local function SendWhenReady(st)
    if ThrottleBusy() then
        st.waitReady = true
        st.readySince = Now()
        Log("Auction House busy: waiting until it is ready")
        pcall(events.RegisterEvent, events, "AUCTION_HOUSE_THROTTLED_SYSTEM_READY")
        -- Le signal « prêt » peut ne jamais venir : on vérifie aussi toutes les 0,5 s, et au bout de 10 s on envoie quand même
        local function poll()
            if AH.state ~= st or not st.waitReady then return end
            local late = Now() - st.readySince >= 10
            if ThrottleBusy() and not late then C_Timer.After(0.5, poll); return end
            st.waitReady = false
            pcall(events.UnregisterEvent, events, "AUCTION_HOUSE_THROTTLED_SYSTEM_READY")
            Log(late and "still busy after 10 s: sending anyway" or "Auction House ready (checked)")
            local ok, err = pcall(st.send)
            if not ok then SendFailed(err) else AH.UpdateUI() end
        end
        C_Timer.After(0.5, poll)
        return true
    end
    st.waitReady = false
    return pcall(st.send)
end
function SendFailed(err)
    Log("request failed: " .. tostring(err))
    AH.state = nil
    StopListening()
    print("|cffffd700" .. FC.NAME .. "|r : the full scan could not be started (" .. tostring(err) .. ").")
    AH.UpdateUI()
end

function AH.FullScan(auto)
    local ok, why = AH.CanFullScan()
    if not ok then
        if not auto then print("|cffffd700" .. FC.NAME .. "|r : " .. why .. ".") end
        return false
    end
    local api = AH.API()
    local db = DB()
    AH.state = { api = api, auto = auto, started = Now() }
    Log((auto and "automatic" or "manual") .. " full scan requested (" .. tostring(api) .. " API)")
    Status("Waiting for the server…")
    -- Sécurité armée AVANT l'envoi : pas de réponse (serveur lent, limite) → abandon propre.
    -- Après un abandon, ni nouvelle demande avant 15 min, ni scan automatique avant un scan réussi.
    local token = AH.state
    C_Timer.After(ANSWER_WAIT, function()
        if AH.state == token and not token.processing then
            AH.state = nil
            StopListening()
            db.lastNoAnswer = Now()
            Log("no answer after " .. ANSWER_WAIT .. " s: gave up")
            if not token.auto then
                print("|cffffd700" .. FC.NAME .. "|r : the Auction House server did not answer the full scan. The game's Auction House seems slow right now (this is on the server side, not the addon). Next try in 15 min.")
            end
            AH.UpdateUI()
        end
    end)
    -- La demande compte pour la limite des 15 minutes dès son envoi réel, même sans réponse
    token.send = function()
        token.sentAt = Now()
        Log("request sent to the server")
        db.lastAttempt = Now(); FC.db.global.ahLastAttempt = Now()
        if api == "modern" then
            pcall(events.RegisterEvent, events, "REPLICATE_ITEM_LIST_UPDATE")
            pcall(events.RegisterEvent, events, "AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED")
            C_AuctionHouse.ReplicateItems()
        else
            QueryAuctionItems("", nil, nil, 0, false, nil, true, false, nil)
        end
    end
    local sent, err
    if api == "modern" then sent, err = SendWhenReady(token) else sent, err = pcall(token.send) end
    if not sent then SendFailed(err); return false end
    AH.UpdateUI()
    return true
end

-- ── Relevés passifs (recherches normales) ────────────────────────────────
local function PassiveBrowse(results)
    if not Opt("ah_passive") or not results then return end
    local batch = {}
    for _, r in ipairs(results) do
        local id = r.itemKey and r.itemKey.itemID
        if id and r.minPrice and r.minPrice > 0 then
            -- plusieurs variantes (niveau d'objet, suffixe) peuvent partager un ID : minimum et total
            local b = batch[id]
            if b then b[1] = math.min(b[1], r.minPrice); b[2] = b[2] + (r.totalQuantity or 0)
            else batch[id] = { r.minPrice, r.totalQuantity or 1 } end
        end
    end
    AH.Commit(batch, true)
end

local function PassiveLegacyPage()
    if not Opt("ah_passive") or not GetNumAuctionItems then return end
    local n, total = GetNumAuctionItems("list")
    n = n or 0
    if n <= 0 or n > 200 then return end   -- une page de recherche, pas un scan complet
    local batch = {}
    for k = 1, n do
        local name, count, buyout, id = LegacyInfo(k)
        Collect(batch, id, buyout, count, name)
    end
    -- Tous les résultats tiennent sur cette page : les quantités des objets vus sont complètes
    AH.Commit(batch, false, total ~= nil and total <= n)
end

events:SetScript("OnEvent", function(_, ev, ...)
    if not FC.db then return end
    if Opt("ah_enabled") == false and ev ~= "AUCTION_HOUSE_CLOSED" then
        if ev == "AUCTION_HOUSE_SHOW" then AH.open = true; AH.CreateUI(); AH.UpdateUI() end
        return
    end
    if ev == "AUCTION_HOUSE_SHOW" then
        Log("Auction House opened")
        AH.open = true
        AH.CreateUI()
        AH.UpdateUI()
        -- Scan automatique, sauf si la dernière demande est restée sans réponse : on n'insiste pas
        -- (chaque nouvelle demande ralentit encore le serveur) ; le bouton reste là, et un scan réussi le relance
        local db = DB()
        local stalled = db and (db.lastNoAnswer or 0) > (db.lastFull or 0)
        if not Opt("ah_autoscan") then Log("automatic scan off")
        elseif stalled then Log("automatic scan paused: the last request got no answer")
        elseif not AH.CanFullScan() then Log("automatic scan: " .. select(2, AH.CanFullScan())) end
        if Opt("ah_autoscan") and not stalled and AH.CanFullScan() then
            C_Timer.After(1.5, function() if AH.open then AH.FullScan(true) end end)
        end
    elseif ev == "AUCTION_HOUSE_CLOSED" then
        Log("Auction House closed" .. ((AH.state and not AH.state.processing) and " (scan request dropped)" or ""))
        AH.open = false
        if AH.state and not AH.state.processing then AH.state = nil end
        StopListening()
    elseif ev == "AUCTION_HOUSE_THROTTLED_SYSTEM_READY" then
        -- L'HV est prêt : on envoie la demande qui attendait
        local st = AH.state
        if st and st.waitReady and st.send then
            pcall(events.UnregisterEvent, events, "AUCTION_HOUSE_THROTTLED_SYSTEM_READY")
            st.waitReady = false
            Log("Auction House ready (signal)")
            local ok, err = pcall(st.send)
            if not ok then SendFailed(err) else AH.UpdateUI() end
        end
    elseif ev == "AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED" then
        -- Une demande vient d'être écartée par le jeu juste après la nôtre : on la renvoie une fois
        local st = AH.state
        if st and st.sentAt and not st.processing and not st.resent and (Now() - st.sentAt) <= 10 then
            st.resent = true
            Log("a request was dropped by the game: sending ours again")
            local ok, err = SendWhenReady(st)
            if not ok then SendFailed(err) else AH.UpdateUI() end
        end
    elseif ev == "REPLICATE_ITEM_LIST_UPDATE" then
        StopListening()
        Log("server answered: " .. tostring(C_AuctionHouse.GetNumReplicateItems and C_AuctionHouse.GetNumReplicateItems()) .. " auctions")
        if AH.state and AH.state.api == "modern" and not AH.state.processing then
            AH.state.processing = true
            local n = C_AuctionHouse.GetNumReplicateItems() or 0
            if n == 0 then Finish({}, 0) else Process(n, ModernInfo, 0) end   -- index à partir de 0
        end
    elseif ev == "AUCTION_ITEM_LIST_UPDATE" then
        if AH.state and AH.state.api == "legacy" then
            if not AH.state.processing then
                AH.state.processing = true
                local n = GetNumAuctionItems("list") or 0
                if n == 0 then Finish({}, 0) else Process(n, LegacyInfo, 1) end
            end
        else
            PassiveLegacyPage()
        end
    elseif ev == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" then
        if C_AuctionHouse and C_AuctionHouse.GetBrowseResults then PassiveBrowse(C_AuctionHouse.GetBrowseResults()) end
    elseif ev == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
        PassiveBrowse((...))
    elseif ev == "COMMODITY_SEARCH_RESULTS_UPDATED" then
        local id = ...
        if Opt("ah_passive") and id and C_AuctionHouse.GetCommoditySearchResultInfo then
            local info = C_AuctionHouse.GetCommoditySearchResultInfo(id, 1)
            if info and info.unitPrice and info.unitPrice > 0 then
                local qty = C_AuctionHouse.GetCommoditySearchResultsQuantity and C_AuctionHouse.GetCommoditySearchResultsQuantity(id) or info.quantity
                AH.Commit({ [id] = { info.unitPrice, qty or 1 } }, true)
            end
        end
    end
end)

function FC:initAuction()
    for _, ev in ipairs({ "AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED", "AUCTION_ITEM_LIST_UPDATE",
        "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", "AUCTION_HOUSE_BROWSE_RESULTS_ADDED", "COMMODITY_SEARCH_RESULTS_UPDATED" }) do
        pcall(events.RegisterEvent, events, ev)   -- certains évènements n'existent pas selon le client
    end
    -- Nettoyage de l'historique trop ancien (une fois par jour)
    local db = DB()
    if db and (db.pruned or 0) < Today() then
        local cut = Today() - (Opt("ah_keep_days") or 60)
        for id, e in pairs(db.items) do
            if e.h and e.h:match("^(%d+)") and tonumber(e.h:match("^(%d+)")) < cut then
                local keep = {}
                for _, x in ipairs(AH.ParseHistory(e.h)) do if x[1] >= cut then keep[#keep + 1] = x end end
                e.h = WriteHistory(keep)
            end
            -- relevés détaillés d'avant-hier et plus : retirés (le point du jour reste dans h)
            if e.r then
                local from, k = YesterdayStart(Now()), {}
                for _, x in ipairs(AH.ParseRecent(e.r)) do if x[1] >= from then k[#k + 1] = x end end
                e.r = #k > 0 and WriteHistory(k) or nil
            end
            -- objet plus vu depuis la durée de conservation : supprimé
            if (e.t or 0) < (cut * 86400) then db.items[id] = nil end
        end
        db.pruned = Today()
    end
end

-- ── Barre sous la fenêtre de l'HV : bouton de scan + état ────────────────
function AH.CreateUI()
    if ui then return end
    local host = (AH.API() == "modern" and _G.AuctionHouseFrame) or _G.AuctionFrame or _G.AuctionHouseFrame
    if not host then return end
    ui = CreateFrame("Frame", nil, host)
    ui:SetSize(360, 26)
    ui:SetPoint("TOPRIGHT", host, "BOTTOMRIGHT", -4, -2)
    ui.icon = ui:CreateTexture(nil, "ARTWORK")
    ui.icon:SetSize(20, 20); ui.icon:SetPoint("RIGHT", -2, 0)
    ui.icon:SetTexture("Interface\\AddOns\\ForeverCompanion\\Media\\LogoAddon.tga")
    ui.btn = API.CreateMenuButton(ui, 110, 22, "Full scan")
    ui.btn:SetPoint("RIGHT", ui.icon, "LEFT", -4, 0)
    ui.btn:SetScript("OnClick", function() AH.FullScan(false) end)
    ui.btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(FC.NAME .. " — full scan", 1, 0.82, 0)
        GameTooltip:AddLine("Records the lowest buyout of every item on sale. The game allows one full scan every 15 minutes.", 1, 1, 1, true)
        local db = DB()
        if db and (db.lastFull or 0) > 0 then GameTooltip:AddLine("Last full scan: " .. AH.Age(db.lastFull) .. " ago", 0.7, 0.7, 0.7) end
        GameTooltip:Show()
    end)
    ui.btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    ui.status = ui:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    ui.status:SetPoint("RIGHT", ui.btn, "LEFT", -8, 0); ui.status:SetJustifyH("RIGHT")
    -- Mise à jour du compte à rebours
    ui.elapsed = 0
    ui:SetScript("OnUpdate", function(self, dt)
        self.elapsed = self.elapsed + dt
        if self.elapsed > 1 then self.elapsed = 0; if not (AH.state and AH.state.processing) then AH.UpdateUI() end end
    end)
end

function AH.UpdateUI()
    if not ui then return end
    ui:SetShown(Opt("ah_enabled") ~= false)
    if AH.state then
        ui.btn:Disable()
        if not AH.state.processing then
            if AH.state.waitReady then Status("Waiting for the Auction House to be ready…")
            else Status(string.format("Waiting for the server… %d s", math.max(0, Now() - (AH.state.sentAt or AH.state.started)))) end
        end
        return
    end
    local ok, why = AH.CanFullScan()
    if ok then ui.btn:Enable() else ui.btn:Disable() end
    local db = DB()
    local noAnswer = db and (db.lastNoAnswer or 0) > (db.lastFull or 0)
    if ok then
        Status((db and (db.lastFull or 0) > 0) and ("Last scan " .. AH.Age(db.lastFull) .. " ago") or "No full scan yet")
    else
        Status((noAnswer and "No answer from the server · " or "") .. why)
    end
end

-- ── Info-bulles ──────────────────────────────────────────────────────────
local function StackCount(tt)
    local owner = tt.GetOwner and tt:GetOwner()
    if type(owner) ~= "table" then return nil end
    local n = tonumber(rawget(owner, "count") or owner.count)
    if not n and type(owner.Count) == "table" and type(owner.Count.GetText) == "function" then n = tonumber(owner.Count:GetText()) end   -- bouton d'objet des sacs
    return (n and n > 1) and n or nil
end

-- Prix à l'unité ; avec Maj enfoncée, prix de la pile survolée en plus
function FC:AddPriceLines(tt, id)
    if not FC.db or Opt("ah_enabled") == false then return false end
    local added = false
    local stack = StackCount(tt)
    local showStack = stack and IsShiftKeyDown and IsShiftKeyDown()
    local e = FC:GetAuctionEntry(id)
    if e and e.m and Opt("ah_tooltip") ~= false then
        tt:AddDoubleLine("|cffffd100Auction|r |cff9d9d9d(" .. AH.Age(e.t) .. ")|r", API.Money(e.m, true), 1, 1, 1, 1, 1, 1)
        if showStack then tt:AddDoubleLine("  Stack x" .. stack, API.Money(e.m * stack, true), 0.7, 0.7, 0.7, 1, 1, 1) end
        if Opt("ah_tooltip_avg") and e.a and e.a ~= e.m then
            tt:AddDoubleLine("  7-day average", API.Money(e.a, true), 0.7, 0.7, 0.7, 1, 1, 1)
        end
        added = true
    end
    if Opt("ah_tooltip_vendor") then
        local sell = select(11, API.GetItemInfo(id))
        if sell and sell > 0 then
            tt:AddDoubleLine("|cffffd100Vendor|r", API.Money(sell, true), 1, 1, 1, 1, 1, 1)
            if showStack then tt:AddDoubleLine("  Stack x" .. stack, API.Money(sell * stack, true), 0.7, 0.7, 0.7, 1, 1, 1) end
            added = true
        end
    end
    return added
end
