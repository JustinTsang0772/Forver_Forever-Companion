-- Forever Companion — Reputation.lua
-- Suivi automatique de la réputation (désactivé par défaut ; Options > Tabs & features, Quick setup) :
-- la barre de réputation du jeu suit la dernière réputation qui a monté.
-- Une même action peut changer plusieurs réputations : une hausse qui en fait baisser d'autres
-- (pirates de la Voile sanglante + / Baie-du-Butin -), ou une hausse qui rejaillit sur des factions
-- liées (Baie-du-Butin + avec un peu de Gadgetzan, Ratchet, Long-guet). Les messages arrivés ensemble
-- sont regroupés, les baisses ignorées, et c'est la plus forte hausse qui est suivie.
-- En combat, le changement attend la fin du combat.
local FC = ForeverCompanion

local BURST = 0.3   -- secondes : messages d'une même action (mort d'un monstre, quête rendue)

local function On() return FC.db ~= nil and FC.db.global.rep_autowatch == true end

-- ── Messages du jeu (langue du client) ────────────────────────────────────
-- « Votre réputation auprès de %s a augmenté de %d. » → motif Lua : nom, montant
local function Pattern(fmt)
    local s = fmt:gsub("%%%d*%$?s", "\001"):gsub("%%%d*%$?d", "\002"):gsub("%%%d*%$?%.?%d*[fg]", "\003")
    s = s:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
    s = s:gsub("\001", "(.-)"):gsub("\002", "(%%d+)"):gsub("\003", "[%%d%%.,]+")
    return "^" .. s .. "$"
end
local patterns
local function Patterns()
    if patterns then return patterns end
    patterns = {}
    for _, k in ipairs({ "FACTION_STANDING_INCREASED", "FACTION_STANDING_INCREASED_BONUS", "FACTION_STANDING_INCREASED_DOUBLE_BONUS",
        "FACTION_STANDING_INCREASED_ACH_BONUS", "FACTION_STANDING_INCREASED_GENERIC" }) do
        local fmt = rawget(_G, k)
        if type(fmt) == "string" and fmt:find("%%") then patterns[#patterns + 1] = Pattern(fmt) end
    end
    if #patterns == 0 then patterns[1] = Pattern("Reputation with %s increased by %d.") end
    return patterns
end
-- Nom et montant d'une hausse (nil pour une baisse ou un autre message)
local function ParseGain(msg)
    msg = tostring(msg or "")
    for _, p in ipairs(Patterns()) do
        local name, amount = msg:match(p)
        if name and name ~= "" then return name, tonumber(amount) or 1 end
    end
end
FC.ReputationParseGain = ParseGain   -- tests

-- ── Liste des réputations du jeu (API actuelle ou ancienne) ───────────────
local function R(k) local t = rawget(_G, "C_Reputation"); return t and t[k] end
local function NumFactions()
    local f = R("GetNumFactions") or rawget(_G, "GetNumFactions")
    return f and f() or 0
end
local function FactionAt(i)
    local byIndex = R("GetFactionDataByIndex")
    if byIndex then
        local d = byIndex(i)
        if not d then return nil end
        return d.name, d.isHeader, d.isCollapsed, d.factionID, d.isWatched, d.isHeaderWithRep or d.hasRep
    end
    local name, _, _, _, _, _, _, _, isHeader, isCollapsed, hasRep, isWatched, _, factionID = GetFactionInfo(i)
    return name, isHeader, isCollapsed, factionID, isWatched, hasRep
end
local function Expand(i) local f = R("ExpandFactionHeader") or rawget(_G, "ExpandFactionHeader"); if f then f(i) end end
local function Collapse(i) local f = R("CollapseFactionHeader") or rawget(_G, "CollapseFactionHeader"); if f then f(i) end end
local function SetWatched(i, id)
    local byID = R("SetWatchedFactionByID")
    if byID and id then byID(id); return end
    local f = R("SetWatchedFactionByIndex") or rawget(_G, "SetWatchedFactionIndex")
    if f then f(i) end
end

-- Suit la réputation « name » ; les catégories repliées sont ouvertes le temps de la chercher, puis refermées
local function Watch(name)
    local function find(openCollapsed, opened)
        local i = 1
        while i <= NumFactions() do
            local n, isHeader, isCollapsed, id, isWatched, hasRep = FactionAt(i)
            if n == name and (not isHeader or hasRep) then
                if not isWatched then SetWatched(i, id) end
                return true
            end
            if openCollapsed and isHeader and isCollapsed then Expand(i); opened[#opened + 1] = i end
            i = i + 1
        end
        return false
    end
    if find(false) then return true end
    local opened = {}
    local ok = find(true, opened)
    for k = #opened, 1, -1 do Collapse(opened[k]) end   -- de la dernière à la première : les index restent bons
    return ok
end
FC.ReputationWatch = Watch   -- tests

-- ── Hausses regroupées, plus forte hausse suivie ──────────────────────────
local pending, queued, waiting = {}, false, nil
local function Flush()
    queued = false
    local best, amount = nil, 0
    for n, a in pairs(pending) do if a > amount or (a == amount and best and n < best) then best, amount = n, a end end
    pending = {}
    if not best or not On() then return end
    if InCombatLockdown and InCombatLockdown() then waiting = best; return end
    waiting = nil
    pcall(Watch, best)
end

local ev = CreateFrame("Frame")
pcall(ev.RegisterEvent, ev, "CHAT_MSG_COMBAT_FACTION_CHANGE")
pcall(ev.RegisterEvent, ev, "PLAYER_REGEN_ENABLED")
ev:SetScript("OnEvent", function(_, e, msg)
    if not On() then pending, waiting = {}, nil; return end
    if e == "PLAYER_REGEN_ENABLED" then
        if waiting then local n = waiting; waiting = nil; pcall(Watch, n) end
        return
    end
    local name, amount = ParseGain(msg)
    if not name then return end   -- baisse : ignorée
    pending[name] = (pending[name] or 0) + amount
    if not queued then
        queued = true
        C_Timer.After(BURST, Flush)
    end
end)
