-- Forever Companion — TalentFrame.lua v1.5.0
-- Positions: wowtbc.gg (correctes) | Icônes: NRC TBC_TalentData.lua

local FC = ForeverCompanion
-- Arbres de talents (FC.TalentTrees) et builds BiS (FC.TalentBuilds) :
-- données générées par le Studio (Data/Talents.lua). Clés de classe en minuscules.

-- Localisation
local _L = {
    not_required = "Not required in this build",
    bis_points   = "BiS Points: %d / %d",
    prev         = "< Previous",
    next         = "Next >",
    auto         = "chosen for your level",
    rotation     = "Rotation",
    no_build     = "No talent build for this spec",
}
local function InitLocale()
    local locale = GetLocale()
    if locale == "frFR" then
        _L.not_required = "Non requis dans ce build"
        _L.bis_points   = "Points BiS : %d / %d"
        _L.prev         = "< Précédent"
        _L.next         = "Suivant >"
        _L.auto         = "choisi selon ton niveau"
        _L.no_build     = "Aucun build de talents pour cette spé"
    elseif locale == "deDE" then
        _L.not_required = "In diesem Build nicht benötigt"
        _L.bis_points   = "BiS-Punkte: %d / %d"
        _L.prev         = "< Zurück"
        _L.next         = "Weiter >"
    elseif locale == "esES" or locale == "esMX" then
        _L.not_required = "No requerido en esta build"
        _L.bis_points   = "Puntos BiS: %d / %d"
        _L.prev         = "< Anterior"
        _L.next         = "Siguiente >"
    elseif locale == "ptBR" or locale == "ptPT" then
        _L.not_required = "Não necessário nesta build"
        _L.bis_points   = "Pontos BiS: %d / %d"
        _L.prev         = "< Anterior"
        _L.next         = "Seguinte >"
    elseif locale == "ruRU" then
        _L.not_required = "Не требуется в этой сборке"
        _L.bis_points   = "Очки BiS: %d / %d"
        _L.prev         = "< Назад"
        _L.next         = "Вперёд >"
    elseif locale == "koKR" then
        _L.not_required = "이 빌드에 필요하지 않음"
        _L.bis_points   = "BiS 포인트: %d / %d"
        _L.prev         = "< 이전"
        _L.next         = "다음 >"
    elseif locale == "zhCN" then
        _L.not_required = "此天赋树不需要"
        _L.bis_points   = "BiS点数: %d / %d"
        _L.prev         = "< 上一个"
        _L.next         = "下一个 >"
    elseif locale == "zhTW" then
        _L.not_required = "此天賦樹不需要"
        _L.bis_points   = "BiS點數: %d / %d"
        _L.prev         = "< 上一個"
        _L.next         = "下一個 >"
    end
end

local bisFrame        = nil
local talentBtns      = {}
local currentClass    = nil
local displayCn, displaySn = nil, nil
local currentBuilds   = nil
local currentBuildIdx = 1
-- Style de la fenêtre de talents du jeu (PlayerSpellsFrame de WoW Forever) : fond, art HD de la classe,
-- cadre intérieur, séparateurs, en-têtes d'arbre (icône ronde, anneau, nom, points), talents carrés.
-- Seulement si le client a ces textures ; sinon l'ancien style.
local function HasAtlas(name)
    return C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(name) and true or false
end
local GAME_STYLE = HasAtlas("Talents-Background-c60") and HasAtlas("Talents-inner-frame-c60") and HasAtlas("Talents-Main-Ring-c60")
    and HasAtlas("talents-node-square-yellow") and HasAtlas("talents-node-square-gray") and HasAtlas("talents-node-square-shadow")
-- Style du jeu : mêmes mesures que la fenêtre de talents du jeu. L'art de la classe est affiché à sa
-- taille d'origine (1212 x 595, trois panneaux de 404 = un par arbre), entre un bandeau en haut
-- (titre, onglets des builds) et un en bas (boutons). Positions relevées dans la fenêtre du jeu :
-- bandeau du haut de 73, liseré en haut de l'art, en-têtes centrés 96 sous le haut de l'art, petit
-- séparateur jusqu'à 140, séparateurs verticaux de 88 à 556, onglets posés sur l'art à 68 du bord.
local ART_W, ART_H, ART_TOP, ART_BOTTOM = 1212, 595, 73, 44
local COL_W = ART_W / 3
local HDR_Y, HDR_DIV_Y, GRID_TOP, GRID_BOTTOM, GRID_STEP = 96, 140, 154, 24, 62
local FRAME_W = GAME_STYLE and (ART_W + 6) or 870
local FRAME_H = GAME_STYLE and (ART_TOP + ART_H + ART_BOTTOM) or 680
-- Un onglet par build, comme les onglets Principale / Secondaire du jeu (sinon boutons Précédent / Suivant)
local GAME_TABS = GAME_STYLE and HasAtlas("uiframe-activetab-left") and HasAtlas("uiframe-activetab-right")
    and HasAtlas("_uiframe-activetab-center") and HasAtlas("uiframe-tab-left") and HasAtlas("uiframe-tab-right")
    and HasAtlas("_uiframe-tab-center")
local TAB_X, TAB_W, TAB_H = 68, 150, 32
local BG_HIDDEN = 18   -- haut du fond général caché par la barre de titre dans le jeu (de 3 à 21)

-- Classe au format des métadonnées (« warrior » → « Warrior ») et spé avec son icône
local function DispClass(cn)
    if not cn or cn == "" then return nil end
    return cn:sub(1, 1):upper() .. cn:sub(2)
end
local function SpecText(dc, sn)
    local ic = FC:GetSpecIcon(dc, sn)
    return ((type(ic) == "number" and ic > 0) and ("|T" .. ic .. ":16:16:0:0|t ") or "") .. tostring(sn or "")
end

local function SetTabSelected(b, on)
    for _, t in ipairs({ b.LeftActive, b.RightActive, b.MiddleActive }) do t:SetShown(on) end
    for _, t in ipairs({ b.Left, b.Right, b.Middle }) do t:SetShown(not on) end
    for _, t in ipairs({ b.LeftHL, b.MiddleHL, b.RightHL }) do t:SetAlpha(on and 0 or 0.4) end
    if on then b.Text:SetTextColor(1, 1, 1) else b.Text:SetTextColor(1, 0.82, 0) end
    b.fcSelected = on
end

-- Onglet au dessin de ceux du jeu (mêmes textures et points d'ancrage)
local function MakeTab(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(TAB_W, TAB_H)
    local function tex(atlas, layer)
        local t = b:CreateTexture(nil, layer); t:SetAtlas(atlas, true); return t
    end
    b.LeftActive = tex("uiframe-activetab-left", "BACKGROUND"); b.LeftActive:SetPoint("BOTTOMRIGHT")
    b.RightActive = tex("uiframe-activetab-right", "BACKGROUND"); b.RightActive:SetPoint("BOTTOMLEFT", -7, 0)
    b.MiddleActive = tex("_uiframe-activetab-center", "BACKGROUND")
    b.MiddleActive:SetPoint("LEFT", b.RightActive, "RIGHT"); b.MiddleActive:SetPoint("RIGHT", b.LeftActive, "LEFT")
    b.Left = tex("uiframe-tab-left", "BACKGROUND"); b.Left:SetPoint("BOTTOMRIGHT")
    b.Right = tex("uiframe-tab-right", "BACKGROUND"); b.Right:SetPoint("BOTTOMLEFT", -6, 0)
    b.Middle = tex("_uiframe-tab-center", "BACKGROUND")
    b.Middle:SetPoint("LEFT", b.Right, "RIGHT"); b.Middle:SetPoint("RIGHT", b.Left, "LEFT")
    b.LeftHL = tex("uiframe-tab-left", "HIGHLIGHT"); b.LeftHL:SetPoint("TOPRIGHT", b.Left, "TOPRIGHT")
    b.MiddleHL = tex("_uiframe-tab-center", "HIGHLIGHT")
    b.MiddleHL:SetPoint("LEFT", b.Middle, "LEFT"); b.MiddleHL:SetPoint("RIGHT", b.Middle, "RIGHT")
    b.RightHL = tex("uiframe-tab-right", "HIGHLIGHT"); b.RightHL:SetPoint("TOPLEFT", b.Right, "TOPLEFT")
    for _, t in ipairs({ b.LeftHL, b.MiddleHL, b.RightHL }) do t:SetBlendMode("ADD") end
    -- Onglets du haut : le jeu reprend les textures des onglets du bas, tournées d'un demi-tour
    -- (d'où le morceau « droit » placé à gauche et le « gauche » à droite)
    for _, t in ipairs({ b.LeftActive, b.RightActive, b.MiddleActive, b.Left, b.Right, b.Middle, b.LeftHL, b.MiddleHL, b.RightHL }) do
        if t.SetRotation then t:SetRotation(math.pi) end
    end
    b.Text = b:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    b.Text:SetPoint("CENTER", 0, -4)
    if b.Text.SetWordWrap then b.Text:SetWordWrap(false) end
    b:SetScript("OnClick", function(self)
        if not self.fcSelected and parent.fcPick then parent.fcPick(self.fcIdx) end
    end)
    -- Nom raccourci faute de place : nom complet au survol
    b:SetScript("OnEnter", function(self)
        if self.Text.IsTruncated and self.Text:IsTruncated() then
            GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:AddLine(self.fcName or "", 1, 1, 1); GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    SetTabSelected(b, false)
    return b
end

-- Onglets des builds de la spé affichée ; aucun s'il n'y a pas de build
local function UpdateBuildTabs(f, builds, idx)
    local bar = f.gTabBar
    local tabs = bar.tabs
    local n = builds and #builds or 0
    local widths, total = {}, 0
    for i = 1, n do
        local b = tabs[i]
        if not b then b = MakeTab(bar); tabs[i] = b end
        b.fcName = builds[i].name ~= "" and builds[i].name or ("Build " .. i)
        b.Text:SetWidth(0); b.Text:SetText(b.fcName)
        widths[i] = math.max(TAB_W, math.ceil((b.Text:GetStringWidth() or 0) + 40))
        total = total + widths[i] + 1
    end
    -- Trop d'onglets pour la largeur : tous réduits d'autant
    local k = math.min(1, (ART_W - 2 * TAB_X) / math.max(1, total))
    local x = 0
    for i = 1, n do
        local b, w = tabs[i], math.floor(widths[i] * k)
        b:SetSize(w, TAB_H)
        b:ClearAllPoints(); b:SetPoint("TOPLEFT", bar, "TOPLEFT", x, 0)
        b.Text:SetWidth(w - 20)
        b.fcIdx = i
        SetTabSelected(b, i == idx)
        b:Show()
        x = x + w + 1
    end
    for i = n + 1, #tabs do tabs[i]:Hide() end
end

local function GetPlayerClassAndSpec()
    if FC and FC.DetectPlayerSpec then
        local cn, sn = FC:DetectPlayerSpec()
        if cn and sn then return cn:lower(), sn end
    end
    local _, cn = UnitClass("player")
    if cn then cn = cn:lower() end
    return cn, nil
end

local function CreateBisFrame()
    local f = ForeverCompanionAPI.CreateWindow("ForeverCompanionTalentFrame",UIParent)
    f:SetSize(FRAME_W,FRAME_H)
    f:SetPoint("CENTER")
    f:SetFrameStrata("HIGH")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",f.StartMoving)
    f:SetScript("OnDragStop",f.StopMovingOrSizing)
    ForeverCompanionAPI.CloseOnEscape(f)   -- fermeture par Échap
    f:Hide()
    -- Onglet BiS Talents de la fenêtre de talents du jeu : en surbrillance tant que celle-ci est ouverte
    f:HookScript("OnShow", function() FC:SyncBisTalentTab() end)
    f:HookScript("OnHide", function() FC:SyncBisTalentTab() end)

    f.title = ForeverCompanionAPI.WindowTitle(f)

    f.buildName = f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    f.buildName:SetPoint("TOP",0,-28)
    f.buildName:SetTextColor(0.7,0.9,1)

    f.closeBtn = f.CloseButton

    f.prevBtn = ForeverCompanionAPI.CreateMenuButton(f,100,24)
    f.prevBtn:SetPoint("BOTTOMLEFT",12,14)
    f.prevBtn:SetText(_L.prev)
    f.prevBtn:Hide()

    f.nextBtn = ForeverCompanionAPI.CreateMenuButton(f,100,24)
    f.nextBtn:SetPoint("BOTTOMRIGHT",-12,14)
    f.nextBtn:SetText(_L.next)
    f.nextBtn:Hide()

    -- Rotation du build affiché, ouverte à gauche de la fenêtre (même choix de build)
    f.rotBtn = ForeverCompanionAPI.CreateMenuButton(f,100,24)
    f.rotBtn:SetText(_L.rotation)
    f.rotBtn:SetScript("OnClick",function() if FC.ToggleDockedRotation then FC:ToggleDockedRotation(f, displayCn, displaySn) end end)
    f.rotBtn:Hide()

    f.buildIdx = f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    f.buildIdx:SetPoint("BOTTOM",0,18)
    f.buildIdx:SetTextColor(0.8,0.8,0.8)

    local s1 = FRAME_W*0.33333
    local s2 = FRAME_W*0.66666
    f.trees = {}
    for i = 1,3 do
        local tf = CreateFrame("Frame",nil,f)
        tf:SetClipsChildren(true)
        tf.topLeft     = tf:CreateTexture(nil,"BACKGROUND")
        tf.topRight    = tf:CreateTexture(nil,"BACKGROUND")
        tf.bottomLeft  = tf:CreateTexture(nil,"BACKGROUND")
        tf.bottomRight = tf:CreateTexture(nil,"BACKGROUND")
        tf.topLeft:SetPoint("TOPLEFT")
        tf.topRight:SetPoint("TOPLEFT",    tf.topLeft,"TOPRIGHT")
        tf.bottomLeft:SetPoint("TOPLEFT",  tf.topLeft,"BOTTOMLEFT")
        tf.bottomRight:SetPoint("TOPLEFT", tf.topLeft,"BOTTOMRIGHT")
        tf.label = tf:CreateFontString(nil,"OVERLAY","Game11Font")
        tf.label:SetPoint("TOP",0,-8)
        tf.ptsFS = tf:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        tf.ptsFS:SetPoint("LEFT",tf.label,"RIGHT",4,0)
        tf.ptsFS:SetTextColor(0.6,0.9,1)
        f.trees[i] = tf
    end
    f.trees[1]:SetPoint("TOPLEFT",6,-46)
    f.trees[1]:SetPoint("BOTTOMRIGHT",f,"BOTTOMLEFT",s1,50)
    f.trees[2]:SetPoint("TOPLEFT",s1,-46)
    f.trees[2]:SetPoint("BOTTOMRIGHT",f,"BOTTOMLEFT",s2,50)
    f.trees[3]:SetPoint("TOPLEFT",s2,-46)
    f.trees[3]:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-6,50)

    if GAME_STYLE then
        f.fcGame = true
        -- Un arbre par panneau de l'art
        for i = 1, 3 do
            local tf = f.trees[i]
            tf:ClearAllPoints()
            tf:SetPoint("TOPLEFT", f, "TOPLEFT", 3 + (i - 1) * COL_W, -ART_TOP)
            tf:SetSize(COL_W, ART_H)
        end
        -- Écran trop petit pour la taille du jeu : la fenêtre est réduite pour tenir
        local function Fit(self)
            local pw, ph = UIParent:GetWidth(), UIParent:GetHeight()
            if type(pw) ~= "number" or type(ph) ~= "number" then return end
            local s = math.min(1, (pw - 40) / FRAME_W, (ph - 60) / FRAME_H)
            if s > 0.3 then self:SetScale(s) end
        end
        if f.HookScript then f:HookScript("OnShow", Fit) end
        -- Fond général (bandeau du haut et du bas). Dans le jeu, il commence 3 sous le haut de la fenêtre,
        -- caché en partie par la barre de titre, et recouvre les stries du haut de la fenêtre. Ici, il
        -- commence sous la barre de titre : on en retire donc le haut caché (BG_HIDDEN) pour que le
        -- dégradé soit le même, et les stries sont masquées (leur bas faisait une coupure dans le bandeau).
        local streaks = f.TopTileStreaks
        if type(streaks) == "table" and streaks.Hide then streaks:Hide() end
        f.gBg = f:CreateTexture(nil, "BACKGROUND", nil, 0)
        f.gBg:SetPoint("TOPLEFT", 3, -21); f.gBg:SetPoint("BOTTOMRIGHT", -3, 4)
        local bgi = C_Texture.GetAtlasInfo("Talents-Background-c60")
        local bgFile = bgi and (bgi.file or bgi.filename)
        if bgFile and bgi.leftTexCoord and bgi.rightTexCoord and bgi.topTexCoord and bgi.bottomTexCoord and (bgi.height or 0) > BG_HIDDEN then
            local t, b = bgi.topTexCoord, bgi.bottomTexCoord
            f.gBg:SetTexture(bgFile)
            f.gBg:SetTexCoord(bgi.leftTexCoord, bgi.rightTexCoord, t + (b - t) * BG_HIDDEN / bgi.height, b)
        else
            f.gBg:SetAtlas("Talents-Background-c60")
        end
        -- Art HD de la classe sous les trois arbres, cadre intérieur
        f.gArt = f:CreateTexture(nil, "BACKGROUND", nil, 1)
        f.gArt:SetPoint("TOPLEFT", f, "TOPLEFT", 3, -ART_TOP); f.gArt:SetSize(ART_W, ART_H)
        f.gBorder = f:CreateTexture(nil, "OVERLAY")
        f.gBorder:SetAtlas("Talents-inner-frame-c60")
        f.gBorder:SetPoint("TOPLEFT", f.gArt, "TOPLEFT", -2, 4); f.gBorder:SetPoint("BOTTOMRIGHT", f.gArt, "BOTTOMRIGHT", 2, -4)
        -- Nom du build (ou message « aucun build ») au milieu du bandeau du haut, s'il n'y a pas d'onglets
        f.buildName:ClearAllPoints(); f.buildName:SetPoint("TOP", 0, -40)
        -- Barre des onglets de builds, posée sur le haut de l'art
        if GAME_TABS then
            f.gTabBar = CreateFrame("Frame", nil, f)
            f.gTabBar:SetSize(ART_W - 2 * TAB_X, TAB_H)
            f.gTabBar:SetPoint("BOTTOMLEFT", f.gArt, "TOPLEFT", TAB_X, 0)
            f.gTabBar.tabs = {}
        end
        -- Liseré orné en haut de l'art (deux moitiés, taille d'origine, comme dans le jeu)
        if HasAtlas("Talents-divider-left-c60") and HasAtlas("Talents-divider-right-c60") then
            f.gTopL = f:CreateTexture(nil, "OVERLAY", nil, 1); f.gTopL:SetAtlas("Talents-divider-left-c60", true)
            f.gTopL:SetPoint("TOPRIGHT", f.gBorder, "TOP", 0, -4)
            f.gTopR = f:CreateTexture(nil, "OVERLAY", nil, 1); f.gTopR:SetAtlas("Talents-divider-right-c60", true)
            f.gTopR:SetPoint("TOPLEFT", f.gBorder, "TOP", 0, -4)
        end
        -- Séparateurs verticaux entre les arbres, sous les en-têtes (taille d'origine)
        if HasAtlas("Talents-divider-vertical-c60") then
            f.gVert = {}
            for i = 1, 2 do
                local d = f:CreateTexture(nil, "OVERLAY")
                d:SetAtlas("Talents-divider-vertical-c60", true)
                d:SetPoint("TOP", f.gArt, "TOPLEFT", i * COL_W, -88)
                f.gVert[i] = d
            end
        end
        -- En-tête de chaque arbre : icône ronde de la spé, anneau, nom, points, petit séparateur
        for i = 1, 3 do
            local tf = f.trees[i]
            for _, t in ipairs({ tf.topLeft, tf.topRight, tf.bottomLeft, tf.bottomRight, tf.label, tf.ptsFS }) do t:Hide() end
            local h = CreateFrame("Frame", nil, tf)
            h:SetSize(48, 48)
            h.icon = h:CreateTexture(nil, "BORDER"); h.icon:SetSize(36, 36); h.icon:SetPoint("CENTER", -3, 3)
            if h.CreateMaskTexture then
                local m = h:CreateMaskTexture()
                m:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
                m:SetSize(40, 40); m:SetPoint("CENTER", -2, 2)
                h.icon:AddMaskTexture(m)
            end
            h.ring = h:CreateTexture(nil, "OVERLAY", nil, 0); h.ring:SetAtlas("Talents-Main-Ring-c60", true); h.ring:SetPoint("CENTER", h.icon)
            h.name = h:CreateFontString(nil, "OVERLAY", "GameFontWhiteLarge"); h.name:SetPoint("LEFT", 54, 2); h.name:SetJustifyH("LEFT")
            if h.name.SetWordWrap then h.name:SetWordWrap(false) end
            if HasAtlas("Talents-Main-Ring-Box-c60") then
                h.box = h:CreateTexture(nil, "OVERLAY", nil, 1); h.box:SetAtlas("Talents-Main-Ring-Box-c60", true); h.box:SetPoint("CENTER", 14, -12)
            end
            h.pts = h:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h.pts:SetDrawLayer("OVERLAY", 2); h.pts:SetPoint("CENTER", 14, -12)
            if HasAtlas("Talents-small-divider-c60") then
                h.div = tf:CreateTexture(nil, "OVERLAY"); h.div:SetAtlas("Talents-small-divider-c60", true)
                h.div:SetPoint("BOTTOM", tf, "TOP", 0, -HDR_DIV_Y)
            end
            tf.hdr = h
        end
    end

    -- Menu des spés de la classe affichée, en haut à droite : change la spé regardée
    -- (spé à variantes en sous-menu, comme dans la fenêtre BiS : Retribution > Retribution / Shockadin)
    f.specDD = ForeverCompanionAPI.CreateDropdown(f, 190, function()
        local items = {}
        local dc = DispClass(displayCn)
        if not dc then return items end
        local function entry(sn)
            return {
                text = SpecText(dc, sn),
                isSelected = function() return sn == displaySn end,
                func = function()
                    if sn == displaySn then return end
                    FC:OpenBisTalentFrameForSpec(dc, sn)
                    -- rotation accrochée à la fenêtre : même spé (classe au même format que le bouton Rotation)
                    if FC.FollowDockedRotation then FC:FollowDockedRotation(f, displayCn, displaySn) end
                end,
            }
        end
        local grouped = FC:GetSpecsGrouped(dc)
        for i, e in ipairs(grouped) do
            if not e.sub then
                local children = { entry(e.sn) }
                for j = i + 1, #grouped do
                    if not grouped[j].sub then break end
                    children[#children + 1] = entry(grouped[j].sn)
                end
                if #children > 1 then
                    items[#items + 1] = { text = SpecText(dc, e.sn), children = children }
                else
                    items[#items + 1] = children[1]
                end
            end
        end
        return items
    end)
    if f.gArt then   -- dans le bandeau du haut, en face des onglets
        f.specDD.frame:SetPoint("BOTTOMRIGHT", f.gArt, "TOPRIGHT", -TAB_X, 6)
    else
        f.specDD.frame:SetPoint("TOPRIGHT", f, "TOPRIGHT", -10, -22)
    end

    return f
end

-- Fond HD de la classe : l'atlas remplit la zone sans déformation (à sa taille d'origine, il tient
-- exactement ; si ses proportions diffèrent, il est recadré au centre)
local function SetClassArt(f, cn, w, h)
    if not f.gArt then return end
    local atlas = "talent-background-" .. tostring(cn or ""):lower()
    local info = HasAtlas(atlas) and C_Texture.GetAtlasInfo(atlas)
    if not info then f.gArt:Hide(); return false end
    f.gArt:Show()
    local file = info.file or info.filename
    local l, r, t, b = info.leftTexCoord, info.rightTexCoord, info.topTexCoord, info.bottomTexCoord
    if not (file and l and r and t and b and info.width and info.height and w > 0 and h > 0) then f.gArt:SetAtlas(atlas); return true end
    -- remplit la zone sans déformer : on rogne la hauteur ou la largeur selon la forme de la zone
    local area, img = h / w, info.height / info.width
    local fx, fy = 1, 1
    if area <= img then fy = area / img else fx = img / area end
    local cu, hu = (l + r) / 2, (r - l) * fx / 2
    local cv, hv = (t + b) / 2, (b - t) * fy / 2
    f.gArt:SetTexture(file)
    f.gArt:SetTexCoord(cu - hu, cu + hu, cv - hv, cv + hv)
    f.gArt.fcArea = { w, h }
    return true
end

local function AdjustBackground(tf, hOverride)
    local w = tf:GetWidth()
    local h = hOverride or tf:GetHeight()
    local tw = w/(256+44)
    local th = h/(256+75)
    tf.topLeft:SetSize(tw*256,th*256)
    tf.topRight:SetSize(tw*64,th*256)
    tf.bottomLeft:SetSize(tw*256,th*128)
    tf.bottomRight:SetSize(tw*64,th*128)
end

local function MakeBtn(parent)
    local btn = CreateFrame("Button",nil,parent)
    btn:SetSize(37,37)
    btn.tex = btn:CreateTexture(nil,"BORDER")
    btn.tex:SetAllPoints()
    local norm = btn:CreateTexture(nil,"BORDER")
    norm:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    norm:SetSize(64,64); norm:SetPoint("CENTER",0,-1)
    btn:SetNormalTexture(norm)
    local pushed = btn:CreateTexture(nil,nil)
    pushed:SetTexture("Interface\\Buttons\\UI-Quickslot-Depress")
    pushed:SetSize(36,36); pushed:SetPoint("CENTER")
    btn:SetPushedTexture(pushed)
    local hl = btn:CreateTexture(nil,"HIGHLIGHT")
    hl:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
    hl:SetBlendMode("ADD"); hl:SetAllPoints()
    btn:SetHighlightTexture(hl)
    btn.outerTex = btn:CreateTexture(nil,"BACKGROUND")
    btn.outerTex:SetTexture("Interface\\Buttons\\UI-EmptySlot-White")
    btn.outerTex:SetSize(64,64); btn.outerTex:SetPoint("CENTER",0,-1)
    btn.rankBg = btn:CreateTexture(nil,"OVERLAY")
    btn.rankBg:SetTexture(136960)
    btn.rankBg:SetSize(20,20); btn.rankBg:SetPoint("BOTTOMRIGHT",8,-8)
    btn.rankFS = btn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    btn.rankFS:SetPoint("CENTER",btn.rankBg)
    btn:SetScript("OnLeave",function() GameTooltip:Hide() end)
    if GAME_STYLE then
        -- Talent carré du jeu : ombre, icône, voile, bordure d'état, rang en chiffres épais
        norm:SetAlpha(0); pushed:SetAlpha(0); hl:SetAlpha(0)
        btn.outerTex:SetAlpha(0); btn.rankBg:SetAlpha(0); btn.rankFS:SetAlpha(0)
        btn.shadow = btn:CreateTexture(nil, "BACKGROUND", nil, -1)
        btn.shadow:SetAtlas("talents-node-square-shadow"); btn.shadow:SetSize(72, 72); btn.shadow:SetPoint("CENTER")
        btn.tex:ClearAllPoints(); btn.tex:SetSize(33, 33); btn.tex:SetPoint("CENTER")
        btn.dim = btn:CreateTexture(nil, "BORDER", nil, 1)
        btn.dim:SetColorTexture(0, 0, 0, 1); btn.dim:SetSize(33, 33); btn.dim:SetPoint("CENTER")
        btn.border = btn:CreateTexture(nil, "ARTWORK"); btn.border:SetAllPoints()
        btn.borderHL = btn:CreateTexture(nil, "HIGHLIGHT"); btn.borderHL:SetAllPoints(); btn.borderHL:SetBlendMode("ADD"); btn.borderHL:SetAlpha(0.4)
        btn.spend = btn:CreateFontString(nil, "OVERLAY", _G.SystemFont16_Shadow_ThickOutline and "SystemFont16_Shadow_ThickOutline" or "NumberFontNormal")
        btn.spend:SetPoint("BOTTOM", 10, 3)
    end
    return btn
end

-- Icône ronde de l'en-tête d'un arbre : la spé rattachée à cet arbre (hors variante), sinon celle du même nom
local function TreeIcon(dispCn, tab, treeName)
    local trees, icons = (FC.SPEC_TREE or {})[dispCn] or {}, (FC.SPEC_ICONS or {})[dispCn] or {}
    local variants = (FC.SPEC_VARIANT_OF or {})[dispCn] or {}
    for _, sn in ipairs((FC.SPEC_ORDER or {})[dispCn] or {}) do
        if trees[sn] == tab and icons[sn] and not variants[sn] then return icons[sn] end
    end
    for sn, ic in pairs(icons) do if tostring(sn):lower() == tostring(treeName):lower() then return ic end end
    return (FC.CLASS_ICONS or {})[dispCn] or "Interface\\Icons\\INV_Misc_QuestionMark"
end

-- État d'un talent au style du jeu : bordure jaune et rang si le build y met des points, grise et voilée sinon
local function StyleNode(btn, ranks)
    if not btn.border then return end
    local on = (ranks or 0) > 0
    local atlas = on and "talents-node-square-yellow" or "talents-node-square-gray"
    btn.border:SetAtlas(atlas); btn.borderHL:SetAtlas(atlas)
    btn.tex:SetDesaturated(not on)
    btn.dim:SetShown(not on); btn.dim:SetAlpha(0.45)
    btn.spend:SetText(on and tostring(ranks) or "")
    btn.spend:SetTextColor(1, 1, 0)
end

-- ── Flèches de prérequis ─────────────────────────────────────────────────
-- req = indice du talent requis dans le même arbre (Studio). Dessinées comme celles du jeu
-- (Blizzard_SharedTalentEdgeTemplates) : trait « talents-arrow-line » de 6 px tiré du centre du talent
-- requis jusqu'au bord du talent qui en dépend, pointe « talents-arrow-head » posée sur ce bord et
-- tournée dans l'axe ; jaune si le talent requis est au maximum dans le build, grise sinon.
-- Secours (client sans ces textures) : trait et pointe dessinés, le trait s'arrête sous la pointe.
local BTN = 37
local EDGE_MIN, EDGE_MAX = 1.2, 1.5   -- distance de la pointe au centre, en demi-largeurs (TalentButtonUtil)
local function AtlasOK(name)
    return C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(name) and true or false
end
local gameArrows
local function GameArrows()
    if gameArrows == nil then
        gameArrows = AtlasOK("talents-arrow-line-yellow") and AtlasOK("talents-arrow-head-yellow")
            and AtlasOK("talents-arrow-line-gray") and AtlasOK("talents-arrow-head-gray") or false
    end
    return gameArrows
end
local function HideTalentArrows(tf)
    for _, t in ipairs(tf.reqLines or {}) do t:Hide() end
    for _, t in ipairs(tf.reqHeads or {}) do t:Hide() end
end
local function DrawTalentArrows(tf, talents, bisTalents, offX, offY, padY, padX)
    padY, padX = padY or 0, padX or 0
    tf.reqLines, tf.reqHeads = tf.reqLines or {}, tf.reqHeads or {}
    HideTalentArrows(tf)
    local game = GameArrows() and tf.CreateLine
    local nl, nh = 0, 0
    local function newLine()
        nl = nl + 1
        local t = tf.reqLines[nl]
        if not t then
            if game then t = tf:CreateLine(nil, "ARTWORK", nil, 1); t:SetThickness(6)
            else t = tf:CreateTexture(nil, "ARTWORK", nil, 1) end
            tf.reqLines[nl] = t
        end
        t:Show()
        return t
    end
    local function newHead()
        nh = nh + 1
        local t = tf.reqHeads[nh]
        if not t then t = tf:CreateTexture(nil, "ARTWORK", nil, 2); tf.reqHeads[nh] = t end
        t:ClearAllPoints()
        t:Show()
        return t
    end
    for _, d in ipairs(talents or {}) do
        local p = d.req and talents[d.req]
        if p and p ~= d and p.row and p.col and d.row and d.col then
            local met = ((bisTalents or {})[d.req - 1] or 0) >= (p.ranks or 1)
            -- centres des deux talents (repère du cadre de l'arbre : y vers le haut)
            local sx, sy = p.col * offX + padX + BTN / 2, -(p.row * offY + padY + BTN / 2)
            local ex, ey = d.col * offX + padX + BTN / 2, -(d.row * offY + padY + BTN / 2)
            local angle = math.atan2(sy - ey, sx - ex)   -- du talent dépendant vers le talent requis
            local k = EDGE_MIN + (EDGE_MAX - EDGE_MIN) * math.abs(math.sin(2 * angle))
            local hx, hy = ex + (BTN / 2) * math.cos(angle) * k, ey + (BTN / 2) * math.sin(angle) * k
            if game then
                local line = newLine()
                line:SetAtlas(met and "talents-arrow-line-yellow" or "talents-arrow-line-gray", false)
                if line.SetHorizTile then line:SetHorizTile(true) end
                line:SetStartPoint("TOPLEFT", tf, sx, sy)
                line:SetEndPoint("TOPLEFT", tf, hx, hy)
                local head = newHead()
                head:SetTexCoord(0, 1, 0, 1)
                head:SetAtlas(met and "talents-arrow-head-yellow" or "talents-arrow-head-gray", true)
                head:SetPoint("CENTER", tf, "TOPLEFT", hx, hy)
                head:SetRotation(angle - math.pi / 2)
            else
                -- Secours : trait de 4 px jusqu'à la base de la pointe (droit ; en biais, horizontal puis vertical)
                local r, g, b = 0.55, 0.55, 0.55
                if met then r, g, b = 1, 0.82, 0 end
                local W, HEAD = 4, 12
                local function bar(x1, y1, x2, y2)   -- segment horizontal ou vertical
                    local t = newLine()
                    t:ClearAllPoints()
                    t:SetColorTexture(r, g, b, 0.9)
                    t:SetPoint("TOPLEFT", tf, "TOPLEFT", math.min(x1, x2) - (x1 == x2 and W / 2 or 0), math.max(y1, y2) + (y1 == y2 and W / 2 or 0))
                    t:SetSize(x1 == x2 and W or math.abs(x2 - x1), y1 == y2 and W or math.abs(y2 - y1))
                end
                local head = newHead()
                head:SetTexture("Interface\\ChatFrame\\ChatFrameExpandArrow")
                head:SetSize(HEAD, HEAD)
                head:SetVertexColor(r, g, b)
                if p.col == d.col then   -- vers le bas
                    local tipY = ey + BTN / 2 + 1
                    bar(sx, sy, sx, tipY + HEAD - 2)
                    head:SetTexCoord(0, 1, 1, 1, 0, 0, 1, 0); head:SetPoint("BOTTOM", tf, "TOPLEFT", ex, tipY)
                elseif p.row == d.row then   -- sur le côté
                    local dir = ex > sx and 1 or -1
                    local tipX = ex - dir * (BTN / 2 + 1)
                    bar(sx, sy, tipX - dir * (HEAD - 2), sy)
                    if dir > 0 then head:SetTexCoord(0, 1, 0, 1); head:SetPoint("RIGHT", tf, "TOPLEFT", tipX, ey)
                    else head:SetTexCoord(1, 0, 0, 1); head:SetPoint("LEFT", tf, "TOPLEFT", tipX, ey) end
                else   -- en biais : vers la colonne du talent, puis vers le bas
                    local tipY = ey + BTN / 2 + 1
                    bar(sx, sy, ex, sy); bar(ex, sy, ex, tipY + HEAD - 2)
                    head:SetTexCoord(0, 1, 1, 1, 0, 0, 1, 0); head:SetPoint("BOTTOM", tf, "TOPLEFT", ex, tipY)
                end
            end
        end
    end
end

local function DisplayBuild(idx)
    if not currentBuilds or not bisFrame then return end
    idx = math.max(1,math.min(idx,#currentBuilds))
    currentBuildIdx = idx
    local build = currentBuilds[idx]
    local cn, sn = displayCn, displaySn
    if not cn then cn, sn = GetPlayerClassAndSpec() end
    local dispCn = cn and (cn:sub(1,1):upper()..cn:sub(2)) or "?"
    bisFrame.title:SetText("BiS Talents — "..(sn or "?").." "..dispCn)
    if bisFrame.specDD then bisFrame.specDD.SetText(SpecText(dispCn, sn)) end
    -- Spé sans build : arbres vides et message, plutôt que l'ancien affichage d'une autre spé
    if build.empty then
        bisFrame.buildName:SetText("|cFFFF9933".._L.no_build.."|r")
        bisFrame.buildIdx:SetText("")
    else
        bisFrame.buildName:SetText(build.name)
        local _, _, isAuto = FC:GetBuildIndex(cn, sn)
        bisFrame.buildIdx:SetText("Build "..idx.." / "..#currentBuilds..((#currentBuilds > 1 and isAuto) and ("  ·  ".._L.auto) or ""))
    end
    -- Onglets (style du jeu) : un par build, ils remplacent le nom, le compteur et Précédent / Suivant
    local arrows = #currentBuilds > 1
    if bisFrame.gTabBar then
        UpdateBuildTabs(bisFrame, not build.empty and currentBuilds or nil, idx)
        if not build.empty then bisFrame.buildName:SetText("") end
        bisFrame.buildIdx:SetText("")
        arrows = false
    end
    if arrows then bisFrame.prevBtn:Show(); bisFrame.nextBtn:Show()
    else bisFrame.prevBtn:Hide(); bisFrame.nextBtn:Hide() end
    bisFrame.rotBtn:ClearAllPoints()
    bisFrame.rotBtn:SetPoint("BOTTOMLEFT", arrows and 118 or 12, 14)
    if FC.HasRotation and FC:HasRotation(cn, sn) then bisFrame.rotBtn:Show() else bisFrame.rotBtn:Hide() end

    -- Reset boutons si classe changée
    if currentClass ~= cn then
        for t = 1,3 do
            if talentBtns[t] then
                for _,b in ipairs(talentBtns[t]) do b:Hide() end
            end
            talentBtns[t] = nil
        end
        currentClass = cn
    else
        for t = 1,3 do
            if talentBtns[t] then
                for _,b in ipairs(talentBtns[t]) do b:Hide() end
            end
        end
    end

    local classIconData = cn and FC.TalentTrees[cn]
    if not classIconData then return end

    -- offX centré sur 4 colonnes dans chaque arbre
    local treeW = FRAME_W / 3
    local offX = (treeW - 37) / 5   -- col1=1slot, col4=4slots, +1 marge
    -- offY distribué sur 9 rows avec marge haut/bas
    local offY = (FRAME_H - 38 + 45 - 80) / 10.0   -- espacement vertical des paliers
    -- Hauteur adaptée au nombre de paliers (7 sur WoW Forever, 9 sur TBC)
    local maxRow = 5
    for t = 1, 3 do
        for _, ti in ipairs((classIconData[t] or {}).talents or {}) do
            if ti.row and ti.row > maxRow then maxRow = ti.row end
        end
    end
    local treeH = maxRow * offY + 37 + 22
    local padX, padY = 0, 0
    if bisFrame.fcGame then
        -- Taille fixe du jeu : 4 colonnes centrées dans le panneau de l'arbre, paliers sous l'en-tête,
        -- resserrés seulement s'il y en a trop pour la hauteur de l'art (9 paliers)
        treeW, treeH = COL_W, ART_H
        offX = GRID_STEP
        padX = (COL_W - 3 * offX - BTN) / 2 - offX
        offY = math.min(GRID_STEP, (ART_H - GRID_BOTTOM - BTN - GRID_TOP) / math.max(1, maxRow - 1))
        padY = GRID_TOP - offY
    else
        bisFrame:SetHeight(46 + 50 + treeH)
    end
    -- Style du jeu : art HD de la classe (sinon les anciens fonds par arbre), portrait de la classe
    local oldBg = true
    if bisFrame.fcGame then
        oldBg = not SetClassArt(bisFrame, cn, ART_W, ART_H)
        if not bisFrame.fcPortrait then
            bisFrame.fcPortrait = true
            if ButtonFrameTemplate_ShowPortrait then pcall(ButtonFrameTemplate_ShowPortrait, bisFrame) end
        end
        local cIcon = (FC.CLASS_ICONS or {})[dispCn] or ("Interface\\Icons\\ClassIcon_" .. tostring(dispCn))
        if bisFrame.SetPortraitToAsset then pcall(bisFrame.SetPortraitToAsset, bisFrame, cIcon) end
    end

    for tab = 1,3 do HideTalentArrows(bisFrame.trees[tab]) end
    for tab = 1,3 do
        local treeData = classIconData[tab]
        if not treeData then break end
        local tf = bisFrame.trees[tab]

        -- Background
        local bgName = ForeverCompanionAPI.TalentBgName(treeData.bg)
        tf.topLeft:SetTexture("Interface\\TalentFrame\\"..bgName.."-TopLeft")
        tf.topRight:SetTexture("Interface\\TalentFrame\\"..bgName.."-TopRight")
        tf.bottomLeft:SetTexture("Interface\\TalentFrame\\"..bgName.."-BottomLeft")
        tf.bottomRight:SetTexture("Interface\\TalentFrame\\"..bgName.."-BottomRight")
        AdjustBackground(tf, treeH)
        for _, t in ipairs({ tf.topLeft, tf.topRight, tf.bottomLeft, tf.bottomRight }) do t:SetShown(oldBg) end
        tf.label:SetText("|cFFFFFF00"..treeData.treeName.."|r")

        local bisTalents = build.tabs[tab] or {}
        local bisPoints = 0
        for _,r in pairs(bisTalents) do bisPoints = bisPoints + r end
        tf.ptsFS:SetText(bisPoints>0 and "|cFF9CD6DE("..bisPoints..")|r" or "")
        if tf.hdr then   -- en-tête au style du jeu : icône, nom centré avec elle, points
            local h = tf.hdr
            h.icon:SetTexture(TreeIcon(dispCn, tab, treeData.treeName))
            h.name:SetWidth(0); h.name:SetText(treeData.treeName)
            local nw = math.min(h.name:GetStringWidth() or 0, treeW - 80)
            h.name:SetWidth(nw)
            h:ClearAllPoints()
            h:SetPoint("TOPLEFT", tf, "TOPLEFT", math.max(4, (treeW - 54 - nw) / 2), -(HDR_Y - 24))
            h.pts:SetText(bisPoints)
        end

        if not talentBtns[tab] then talentBtns[tab] = {} end

        for i, talentInfo in ipairs(treeData.talents) do
            local idx0 = i - 1  -- index 0-based comme dans FC.TalentBuilds
            local btn = talentBtns[tab][i]
            if not btn then
                btn = MakeBtn(tf)
                talentBtns[tab][i] = btn
            end
            btn:ClearAllPoints()
            btn:SetPoint("TOPLEFT",tf,"TOPLEFT",
                talentInfo.col * offX + padX,
                -(talentInfo.row * offY + padY))
            btn:Show()
            local API = ForeverCompanionAPI
            local tid = (talentInfo.id and API.SpellExists(talentInfo.id)) and talentInfo.id or nil
            local icon = tid and API.GetSpellIcon(tid) or talentInfo.icon
            if not icon or icon == 0 then
                -- Pas d'icône dans les données : celle du client si c'est la classe du joueur
                local _, playerClass = UnitClass("player")
                if playerClass and playerClass:lower() == cn then icon = ForeverCompanionAPI.FindTalentIcon(tab, talentInfo.name) end
            end
            btn.tex:SetTexture(icon and icon ~= 0 and icon or "Interface\\Icons\\INV_Misc_QuestionMark")

            local bisRanks = bisTalents[idx0]
            if bisRanks and bisRanks > 0 then
                btn.tex:SetDesaturated(false)
                btn.outerTex:SetVertexColor(1,0.84,0)
                btn.rankBg:Show(); btn.rankFS:Show()
                btn.rankFS:SetText(bisRanks)
                if bisRanks >= talentInfo.ranks then
                    btn.rankFS:SetTextColor(1,0.84,0)
                else
                    btn.rankFS:SetTextColor(0.4,1,0.4)
                end
            else
                btn.tex:SetDesaturated(true)
                btn.outerTex:SetVertexColor(0.5,0.5,0.5)
                btn.rankBg:Hide(); btn.rankFS:Hide()
            end
            StyleNode(btn, bisRanks)

            btn.talentName = talentInfo.name
            btn.spellId    = tid
            btn.bisRanks   = bisRanks or 0
            btn.maxRanks   = talentInfo.ranks
            btn:SetScript("OnEnter",function(self)
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                -- Info-bulle du sort (rang 1) si l'ID est connu, puis les points BiS
                if self.spellId and GameTooltip.SetSpellByID and pcall(GameTooltip.SetSpellByID, GameTooltip, self.spellId) then
                    GameTooltip:AddLine(" ")
                    if self.bisRanks>0 then
                        GameTooltip:AddLine(string.format(_L.bis_points, self.bisRanks, self.maxRanks),0.4,0.9,1)
                    else
                        GameTooltip:AddLine(_L.not_required,0.5,0.5,0.5)
                    end
                elseif self.bisRanks>0 then
                    GameTooltip:AddLine(self.talentName,1,0.84,0)
                    GameTooltip:AddLine(string.format(_L.bis_points, self.bisRanks, self.maxRanks),0.4,0.9,1)
                else
                    GameTooltip:AddLine(self.talentName,0.7,0.7,0.7)
                    GameTooltip:AddLine(_L.not_required,0.5,0.5,0.5)
                end
                GameTooltip:Show()
            end)
        end
        DrawTalentArrows(tf, treeData.talents, bisTalents, offX, offY, padY, padX)
    end
end

local function OpenBisTalentFrame(forceClass, forceSpec)
    if not bisFrame then
        bisFrame = CreateBisFrame()
        -- Choix partagé avec la fenêtre Rotation (et mémorisé)
        local function pick(i)
            if not currentBuilds then return end
            i = math.max(1, math.min(i, #currentBuilds))
            FC:SetBuildIndex(displayCn, displaySn, i)
            DisplayBuild(i)
        end
        bisFrame.prevBtn:SetScript("OnClick",function() pick(currentBuildIdx-1) end)
        bisFrame.nextBtn:SetScript("OnClick",function() pick(currentBuildIdx+1) end)
        if bisFrame.gTabBar then bisFrame.gTabBar.fcPick = pick end
    end

    -- Re-détecter la spec à chaque ouverture (gère les changements de spé)
    currentClass = nil  -- forcer le reset des boutons
    currentBuilds = nil

    local cn, sn
    if forceClass and forceSpec then
        -- Classe/spec forcées (ex: sélection de la Bislist) — clés minuscules
        cn, sn = forceClass:lower(), forceSpec
    else
        cn, sn = GetPlayerClassAndSpec()
    end
    if not cn or not sn then
        print("|cFFFF6600Forever Companion|r : Spec non détectée."); return
    end
    if not (FC.TalentTrees and FC.TalentTrees[cn]) then
        print("|cFFFF6600Forever Companion|r : no talent trees for "..cn); return
    end
    currentBuilds = FC.TalentBuilds[cn] and FC:GetBuilds(cn, sn)   -- builds de la spé, puis ceux de ses variantes (Shockadin)
    local empty = not currentBuilds or #currentBuilds == 0
    -- Aucun build : la fenêtre montre les arbres vides et le dit (et non le build d'une autre spé)
    if empty then currentBuilds = { { name = "", tabs = {}, empty = true } } end
    -- Mémoriser pour le titre (DisplayBuild ne doit pas re-détecter)
    displayCn, displaySn = cn, sn
    currentBuildIdx = empty and 1 or (FC:GetBuildIndex(cn, sn) or 1)
    bisFrame:Show(); bisFrame:Raise()
    DisplayBuild(currentBuildIdx)
end

-- Build changé ailleurs (fenêtre Rotation) : mise à jour si la même spé est affichée
function FC:RefreshTalentBuild(cn, sn)
    if not (bisFrame and bisFrame:IsShown() and currentBuilds and displayCn) then return end
    if displayCn ~= tostring(cn):lower() or displaySn ~= sn then return end
    local idx = FC:GetBuildIndex(cn, sn)
    if idx and idx ~= currentBuildIdx then DisplayBuild(idx) end
end

SLASH_FCTALENTS1 = "/fctalents"
SLASH_FCTALENTS2 = "/bistalents"
SlashCmdList["FCTALENTS"] = function() OpenBisTalentFrame() end
function FC:OpenBisTalentFrame() OpenBisTalentFrame() end
function FC:OpenBisTalentFrameForSpec(cn, sn) OpenBisTalentFrame(cn, sn) end

-- ============================================================
-- BOUTON "BiS Talents" dans le TalentFrame Blizzard
-- ============================================================
local bisTalentBtn = nil
-- Fenêtre de talents Blizzard selon le client : Classic (PlayerTalentFrame),
-- jeu actuel (PlayerSpellsFrame, ClassTalentFrame). Le premier trouvé est utilisé.
local TALENT_FRAMES = { "PlayerTalentFrame", "PlayerSpellsFrame", "ClassTalentFrame" }

local function CreateBisTalentButton()
    if bisTalentBtn then return end
    local host
    for _, name in ipairs(TALENT_FRAMES) do
        if _G[name] and _G[name].HookScript then host = _G[name]; break end
    end
    if not host then return end

    -- Onglet sur le bord droit de la fenêtre (talents et grimoire), comme ceux de la fenêtre BiS,
    -- avec la même icône que l'onglet BiS Talents de celle-ci
    bisTalentBtn = ForeverCompanionAPI.CreateSideTab(UIParent)
    bisTalentBtn.fcHost = host
    local icon = "ability_marksmanship"
    for _, t in ipairs(FC.UI_TABS or {}) do if t.id == "talents" and t.icon then icon = t.icon end end
    bisTalentBtn:SetIcon(icon)
    bisTalentBtn.tooltip = "BiS Talents"
    bisTalentBtn.tooltipSub = "Show / hide the recommended talent build of your spec"
    if host.GetFrameStrata then bisTalentBtn:SetFrameStrata(host:GetFrameStrata()) end
    bisTalentBtn:SetScript("OnClick", function()
        if bisFrame and bisFrame:IsShown() then
            bisFrame:Hide()
        else
            OpenBisTalentFrame()
        end
        FC:SyncBisTalentTab()
    end)
    ForeverCompanionAPI.AttachToFrame(bisTalentBtn, host)
    host:HookScript("OnShow", function() FC:PlaceBisTalentTab() end)
    host:HookScript("OnHide", function() if bisFrame then bisFrame:Hide() end end)
    FC:PlaceBisTalentTab()
    FC:SyncBisTalentTab()
end

-- Place de l'onglet : en haut du bord droit de la fenêtre, ou de la liste des sorts du maître
-- quand elle est ouverte à droite du grimoire (l'onglet de cette liste se range alors dessous)
function FC:PlaceBisTalentTab()
    if not bisTalentBtn then return end
    local host = bisTalentBtn.fcHost
    local anchor = (FC.TrainingSideAnchor and FC:TrainingSideAnchor(host)) or host
    bisTalentBtn:ClearAllPoints()
    bisTalentBtn:SetPoint("TOPLEFT", anchor, "TOPRIGHT", bisTalentBtn.style == "forever" and -2 or 1, -60)
end
-- L'onglet est-il affiché sur cette fenêtre ? (la liste des sorts du maître place son onglet dessous)
function FC:BisTalentTabOn(frame)
    return bisTalentBtn ~= nil and bisTalentBtn.fcHost == frame and bisTalentBtn:IsShown() and true or false
end
-- Onglet en surbrillance tant que la fenêtre BiS Talents est ouverte
function FC:SyncBisTalentTab()
    if bisTalentBtn and bisTalentBtn.SetActive then bisTalentBtn:SetActive(bisFrame ~= nil and bisFrame:IsShown()) end
end

local btnFrame = CreateFrame("Frame")
btnFrame:RegisterEvent("PLAYER_LOGIN")
btnFrame:RegisterEvent("ADDON_LOADED")
btnFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "PLAYER_LOGIN" then
        InitLocale()
    end
    -- La fenêtre de talents est chargée à la demande (Blizzard_TalentUI,
    -- Blizzard_PlayerSpells…) : on réessaie à chaque chargement d'addon.
    CreateBisTalentButton()
    if bisTalentBtn then self:UnregisterEvent("ADDON_LOADED") end
end)
