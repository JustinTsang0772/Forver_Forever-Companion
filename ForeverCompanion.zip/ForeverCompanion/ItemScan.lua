-- Forever Companion — ItemScan.lua
-- /fc scan objets : demande au serveur chaque objet des listes BiS (et leurs gemmes)
-- et liste ceux qu'il ne connaît pas. Un objet peut figurer dans les fichiers du jeu
-- sans être actif sur le serveur : il reste alors sans nom ni info-bulle du jeu.
-- Résultat : fenêtre copiable (Ctrl+A puis Ctrl+C), une ligne par objet inconnu
-- « ID = nom | raison | listes », gardé aussi dans les SavedVariables (global.item_scan).
local FC = ForeverCompanion
local API = ForeverCompanionAPI

local MAX_INFLIGHT = 40   -- demandes en attente de réponse en même temps
local PER_TICK     = 10   -- nouvelles demandes par passage (100 par seconde au plus)
local TICK         = 0.1  -- secondes entre deux passages
local TIMEOUT      = 8    -- secondes sans réponse avant de redemander
local MAX_TRIES    = 2    -- demandes par objet avant de conclure

local REASON = {
    absent  = "inconnu des fichiers du jeu",
    refused = "refusé par le serveur",
    noreply = "sans réponse du serveur",
}

local function Now() return GetTime and GetTime() or time() end

-- Objets à vérifier, triés, et pour chacun les listes où il apparaît
local function WantedItems()
    local uses, ids = {}, {}
    local function add(id, where)
        id = tonumber(id)
        if not id or id <= 0 then return end
        local u = uses[id]
        if not u then u = {}; uses[id] = u; table.insert(ids, id) end
        table.insert(u, where)
    end
    for cn, specs in pairs(FC.BisData or {}) do
        for sn, phases in pairs(specs) do
            for ph, slots in pairs(phases) do
                for _, se in ipairs(slots) do
                    local where = cn .. " / " .. sn .. " / " .. tostring(ph) .. " / " .. tostring(se.slot)
                    for _, it in ipairs(se.items or {}) do
                        add(it.itemId, where)
                        for _, g in ipairs(it.gems or {}) do add(g.itemId, where .. " (gemme)") end
                    end
                end
            end
        end
    end
    table.sort(ids)
    for _, u in pairs(uses) do table.sort(u) end
    return ids, uses
end

-- ── Fenêtre d'export (Ctrl+A puis Ctrl+C) ────────────────────────────────
local exportFrame
local function ShowExport(text)
    if not exportFrame then
        local f = API.CreateWindow("ForeverCompanionItemScanFrame", UIParent)
        f:SetSize(560, 420); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG")
        f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
        API.WindowTitle(f):SetText(FC.NAME .. " — Objets inconnus du serveur")
        local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT", 14, -30); hint:SetWidth(530); hint:SetJustifyH("LEFT")
        hint:SetText("Ctrl+A puis Ctrl+C pour copier la liste.")
        local sf = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        sf:SetPoint("TOPLEFT", 12, -52); sf:SetPoint("BOTTOMRIGHT", -32, 12)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true); eb:SetAutoFocus(true); eb:SetFontObject(ChatFontNormal); eb:SetWidth(500)
        eb:SetScript("OnEscapePressed", function() f:Hide() end)
        sf:SetScrollChild(eb)
        f.edit = eb
        API.CloseOnEscape(f)
        exportFrame = f
    end
    exportFrame.edit:SetText(text)
    exportFrame.edit:HighlightText()
    exportFrame:Show()
    exportFrame:Raise()
end

-- ── Scan ─────────────────────────────────────────────────────────────────
local scan     -- scan en cours (nil sinon)
local ticker   -- cadre qui rythme les demandes (réutilisé d'un scan à l'autre)

local function Request(id)
    if C_Item and C_Item.RequestLoadItemDataByID and pcall(C_Item.RequestLoadItemDataByID, id) then return end
    API.GetItemInfo(id)   -- à défaut, GetItemInfo demande aussi l'objet au serveur
end

local function Resolve(id, status)
    local s = scan
    if not s or s.status[id] then return end
    if s.pending[id] then s.pending[id] = nil; s.inflight = s.inflight - 1 end
    s.status[id] = status
    s.done = s.done + 1
end

local function Finish()
    local s = scan
    scan = nil
    ticker:SetScript("OnUpdate", nil)
    local missing, saved = {}, {}
    for _, id in ipairs(s.ids) do
        local st = s.status[id]
        if st ~= "ok" then table.insert(missing, id); saved[id] = st end
    end
    FC.db.global.item_scan = { at = time(), version = FC.VERSION, total = #s.ids, missing = saved }
    print("|cffffd700" .. FC.NAME .. "|r : " .. #s.ids .. " objet(s) vérifié(s), " .. #missing .. " inconnu(s) du serveur.")
    if #missing == 0 then return end
    local lines = {
        "# " .. #s.ids .. " objets des listes BiS vérifiés le " .. date("%d/%m/%Y à %H:%M") .. " (Forever Companion " .. tostring(FC.VERSION) .. ")",
        "# " .. #missing .. " inconnu(s) du serveur : ID = nom | raison | listes",
    }
    for _, id in ipairs(missing) do
        local it = FC.ITEMS and FC.ITEMS[id]
        local name = (it and it.n) or API.GetItemInfo(id) or "?"
        local u = s.uses[id]
        local where = u[1] .. (#u > 1 and (" (+" .. (#u - 1) .. " autre(s) liste(s))") or "")
        table.insert(lines, id .. " = " .. name .. " | " .. (REASON[s.status[id]] or "?") .. " | " .. where)
    end
    ShowExport(table.concat(lines, "\n"))
end

API.OnItemInfo(function(id, ok)
    local s = scan
    local p = s and s.pending[id]
    if not p then return end
    if ok == false then
        -- Refus du serveur : on redemande une fois avant de conclure
        if p.tries >= MAX_TRIES then Resolve(id, "refused")
        else p.tries = p.tries + 1; p.t = Now(); Request(id) end
    elseif API.GetItemInfo(id) then
        Resolve(id, "ok")
    end
end)

function FC:ScanItems()
    if scan then print("|cffffd700" .. self.NAME .. "|r : vérification des objets déjà en cours…"); return end
    local ids, uses = WantedItems()
    if #ids == 0 then print("|cffffd700" .. self.NAME .. "|r : aucune liste BiS à vérifier."); return end
    local s = { ids = ids, uses = uses, status = {}, pending = {}, queue = {}, qi = 1,
                inflight = 0, done = 0, lastPct = 0 }
    scan = s
    -- Tri immédiat : inconnu des fichiers du jeu, ou déjà connu (en cache), sinon à demander
    for _, id in ipairs(ids) do
        if API.ItemExists(id) == false then Resolve(id, "absent")
        elseif API.ItemIsCached(id) and API.GetItemInfo(id) then Resolve(id, "ok")
        else table.insert(s.queue, id) end
    end
    print("|cffffd700" .. self.NAME .. "|r : vérification de " .. #ids .. " objet(s) des listes BiS, dont "
        .. #s.queue .. " à demander au serveur (une à deux minutes)…")
    ticker = ticker or CreateFrame("Frame")
    local acc = TICK
    ticker:SetScript("OnUpdate", function(_, elapsed)
        acc = acc + (elapsed or TICK)
        if acc < TICK then return end
        acc = 0
        local now = Now()
        -- Délais dépassés : nouvelle demande, ou conclusion après MAX_TRIES
        for id, p in pairs(s.pending) do
            if now - p.t >= TIMEOUT then
                if API.GetItemInfo(id) then Resolve(id, "ok")
                elseif p.tries >= MAX_TRIES then Resolve(id, "noreply")
                else p.tries = p.tries + 1; p.t = now; Request(id) end
            end
        end
        -- Nouvelles demandes, au rythme fixé
        local sent = 0
        while s.inflight < MAX_INFLIGHT and sent < PER_TICK and s.qi <= #s.queue do
            local id = s.queue[s.qi]; s.qi = s.qi + 1
            if not s.status[id] then
                s.pending[id] = { t = now, tries = 1 }; s.inflight = s.inflight + 1; sent = sent + 1
                Request(id)
            end
        end
        local pct = math.floor(s.done * 100 / #s.ids)
        if pct >= s.lastPct + 25 and pct < 100 then
            s.lastPct = pct - pct % 25
            print("|cffffd700FC|r scan objets : " .. s.lastPct .. " %")
        end
        if s.qi > #s.queue and s.inflight == 0 then Finish() end
    end)
end
