-- Forever Companion — Bags.lua
-- Sac de composants (l'emplacement de sac à part de WoW Forever) : la touche du sac à dos du jeu
-- (raccourci « Ouvrir le sac à dos », B par défaut) ne l'ouvre pas, alors que « Ouvrir tous les sacs »
-- (Maj+B par défaut) l'ouvre. Option (Options > Items & loot, cochée par défaut) : la touche du sac à dos
-- fait « Ouvrir tous les sacs » ; décochée, elle refait « Ouvrir le sac à dos ».
-- Par un raccourci prioritaire (override) posé par l'addon, sans toucher aux raccourcis enregistrés du
-- joueur : c'est le jeu qui ouvre les sacs, à l'appui de la touche. Rien n'est ouvert par du code de
-- l'addon : pas d'action protégée bloquée ensuite (l'ancienne façon, ouvrir le sac depuis l'addon,
-- bloquait l'achat d'un onglet de banque), et ça marche en combat.
-- Le jeu interdit de poser un raccourci en combat : fait à la fin du combat si besoin.
local FC = ForeverCompanion

local SRC, DST = "TOGGLEBACKPACK", "OPENALLBAGS"   -- « Ouvrir le sac à dos » → « Ouvrir tous les sacs »
local owner = CreateFrame("Frame", "ForeverCompanionBagKeys")
local appliedKeys = ""      -- touches redirigées en ce moment (« B,I »)
local pending = false       -- à refaire à la fin du combat

local function On() return FC.db ~= nil and FC.db.global.reagent_with_bags ~= false end
local function InCombat() return InCombatLockdown and InCombatLockdown() end
-- Le raccourci « Ouvrir tous les sacs » existe dans ce jeu ?
local function HasAction(name)
    if type(GetNumBindings) ~= "function" or type(GetBinding) ~= "function" then return true end
    for i = 1, GetNumBindings() do
        if GetBinding(i) == name then return true end
    end
    return false
end
-- Touches du sac à dos à rediriger (celles du joueur, pas nos redirections)
local function WantedKeys()
    local out = {}
    if not On() or type(GetBindingKey) ~= "function" or not HasAction(DST) then return out end
    for _, k in ipairs({ GetBindingKey(SRC) }) do
        if type(k) == "string" and k ~= "" then out[#out + 1] = k end
    end
    return out
end

local busy = false
local function Apply()
    if busy or type(SetOverrideBinding) ~= "function" or type(ClearOverrideBindings) ~= "function" then return end
    if InCombat() then pending = true; return end
    pending = false
    local keys = WantedKeys()
    local key = table.concat(keys, ",")
    if key == appliedKeys then return end   -- rien de changé
    -- Poser un raccourci relance UPDATE_BINDINGS (parfois tout de suite) : noté avant, et pas de rappel pendant
    appliedKeys = key
    busy = true
    pcall(function()
        ClearOverrideBindings(owner)
        for _, k in ipairs(keys) do SetOverrideBinding(owner, false, k, DST) end
    end)
    busy = false
end
FC.ApplyBagKeys = function() Apply() end   -- option cochée / décochée

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("UPDATE_BINDINGS")   -- le joueur a changé ses raccourcis : on suit sa touche du sac à dos
pcall(ev.RegisterEvent, ev, "PLAYER_REGEN_ENABLED")
ev:SetScript("OnEvent", function(_, e)
    if e == "PLAYER_REGEN_ENABLED" and not pending then return end
    Apply()
end)

-- /fc sacs : diagnostic
function FC:BagsDebug()
    local function P(t) print("|cffffd700FC sacs|r " .. t) end
    local function keys(cmd)
        local t = {}
        if type(GetBindingKey) == "function" then for _, k in ipairs({ GetBindingKey(cmd) }) do t[#t + 1] = tostring(k) end end
        return #t > 0 and table.concat(t, ", ") or "aucune"
    end
    P("option : " .. tostring(On()) .. " ; en attente (combat) : " .. tostring(pending))
    P("« Ouvrir le sac à dos » (" .. SRC .. ") : " .. keys(SRC) .. " ; « Ouvrir tous les sacs » (" .. DST .. ") : "
        .. keys(DST) .. (HasAction(DST) and "" or " (raccourci absent du jeu)"))
    P("touches redirigées vers « Ouvrir tous les sacs » : " .. (appliedKeys ~= "" and appliedKeys or "aucune"))
end

FC.BagsInternals = { Apply = Apply, State = function() return appliedKeys, pending end }   -- tests
