-- Forever Companion — fichier généré par Forever Companion Studio.
-- NE PAS MODIFIER À LA MAIN : toute modification serait écrasée à la prochaine génération.

ForeverCompanionData = ForeverCompanionData or {}
ForeverCompanionData.weights = {
  DRUID={
    {id=1,label="Balance DPS (P1)",tab=1,icon="spell_nature_starfall",w={ArcaneSpellDamage=0.68,CritRating=10.64,HitRating=14.8,Intellect=0.28,Mp5=0.15,NatureSpellDamage=0.32,SpellDamage=1,SpellPower=1}},
    {id=253886,label="Balance DPS (Pre-BiS)",tab=1,icon="spell_nature_starfall",w={ArcaneSpellDamage=0.68,CritRating=10.64,HitRating=14.5,Intellect=0.2,NatureSpellDamage=0.32,SpellDamage=1,SpellPower=1}},
    {id=2,label="Feral DPS",tab=2,icon="ability_druid_catform",w={Agility=0.655,Ap=0.244,CritRating=7.08,FeralAp=0.243,HitRating=5.212,MeleeDps=2.142,Strength=0.594}},
    {id=4,label="Feral Tank",tab=2,icon="ability_racial_bearform",w={Agility=0.433,Ap=0.221,Armor=0.174,CritRating=5.086,DefenseRating=0.876,DodgeRating=1.289,FeralAp=0.221,HitRating=6.879,MeleeDps=3.093,Stamina=1.003,Strength=0.486}},
    {id=3,label="Healer",tab=3,icon="spell_nature_healingtouch",w={CritRating=100,Healing=10,Intellect=3,Mp5=30,SpellPower=10,Spirit=5}},
  },
  HUNTER={
    {id=5,label="DPS (Weave)",tab=1,w={Agility=1,Ap=0.19,CritRating=11.2,HitRating=13.5,Intellect=0.43,MeleeDps=2.75,Mp5=0.07,RangedDps=1.72,Rap=0.2,Strength=0.21}},
    {id=885149,label="DPS (Turret)",tab=1,w={Agility=1,CritRating=11.76,HitRating=11.4,Intellect=0.38,Mp5=0.04,RangedDps=2.87,Rap=0.34}},
    {id=455593,label="DPS (Melee)",tab=1,w={Agility=1,Ap=0.37,CritRating=13.72,HitRating=24.1,Intellect=0.7,MeleeDps=4.53,Mp5=0.28,RangedDps=0.27,Rap=0.15,Strength=0.4}},
  },
  MAGE={
    {id=6,label="DPS",tab=1,icon="spell_holy_magicalsentry",w={CritRating=81,FrostSpellDamage=7,HitRating=100,Intellect=1,SpellPenetration=30,SpellPower=7}},
  },
  PALADIN={
    {id=7,label="Healer",tab=1,icon="spell_holy_holybolt",w={CritRating=100,Healing=5,Intellect=5,Mp5=15,SpellPower=5}},
    {id=8,label="Retribution DPS (Holy Shock)",tab=3,icon="spell_holy_auraoflight",w={Agility=3.11,Ap=1,CritRating=65.24,HitRating=102.5,Intellect=4.53,MeleeDps=13.04,Mp5=0.01,SpellDamage=5.78,SpellPenetration=0.01,SpellPower=5.78,Strength=2.5}},
    {id=990240,label="Retribution DPS (Unsealed Wrath)",tab=3,icon="spell_holy_auraoflight",w={Agility=2.23,Ap=1,CritRating=43.12,HitRating=68.3,Intellect=2.06,MeleeDps=13.85,Mp5=0.23,SpellDamage=2.36,SpellPenetration=0.01,SpellPower=2.36,Strength=2.4}},
  },
  PRIEST={
    {id=257030,label="Discipline Healer (single target)",tab=1,icon="spell_holy_powerwordshield",w={CritRating=9.8,Healing=1,Intellect=0.2,Mp5=0.4,SpellPower=1,Spirit=0.15}},
    {id=815966,label="Discipline Healer (raid)",tab=1,icon="spell_holy_powerwordshield",w={CritRating=6.72,Healing=1,Intellect=0.2,Mp5=0.19,SpellPower=1,Spirit=0.1}},
    {id=925707,label="Smite DPS",tab=2,icon="spell_holy_holysmite",w={CritRating=4.48,HitRating=3.7,HolySpellDamage=0.81,Intellect=0.58,Mp5=1.46,ShadowSpellDamage=0.19,SpellDamage=1,SpellPower=1,Spirit=0.57}},
    {id=9,label="Holy Healer (single target)",tab=2,icon="spell_holy_guardianspirit",w={CritRating=4.2,Healing=1,Intellect=0.35,Mp5=0.6,SpellPower=1,Spirit=0.3}},
    {id=10,label="Holy Healer (raid)",tab=2,icon="spell_holy_guardianspirit",w={CritRating=3.22,Healing=1,Intellect=0.3,Mp5=0.6,SpellPower=1,Spirit=0.25}},
    {id=11,label="Shadow DPS",tab=3,icon="spell_shadow_shadowwordpain",w={CritRating=11.76,HitRating=11.4,Intellect=0.24,ShadowSpellDamage=1,SpellDamage=1,SpellPower=1,Spirit=0.01}},
  },
  ROGUE={
    {id=13,label="Assassination",tab=1,icon="ability_rogue_eviscerate",w={Agility=2.06,Ap=1,CritRating=28.28,HitRating=28,MeleeDps=8.44,SpellPenetration=0.65,Stamina=0.01,Strength=1.1}},
    {id=12,label="Combat (Sinister Strike)",tab=2,icon="ability_backstab",w={Agility=1.96,Ap=1,CritRating=23.8,HitRating=24.2,MeleeDps=10.57,SpellPenetration=0.19,Stamina=0.01,Strength=1.1}},
    {id=325818,label="Combat (Daggers)",tab=2,icon="ability_backstab",w={Agility=1.95,Ap=1,CritRating=23.52,HitRating=23.5,MeleeDps=10.18,SpellPenetration=0.21,Stamina=0.01,Strength=1.1}},
    {id=352377,label="Subtlety",tab=3,icon="ability_stealth",w={Agility=1.93,Ap=1,CritRating=22.82,HitRating=21.2,MeleeDps=10.47,SpellPenetration=0.16,Stamina=0.01,Strength=1.1}},
  },
  SHAMAN={
    {id=15,label="Elemental DPS (Default)",tab=1,icon="spell_nature_lightning",w={CritRating=8.54,FireSpellDamage=0.31,HitRating=11.8,Intellect=0.19,Mp5=0.04,NatureSpellDamage=0.69,SpellDamage=1,SpellPenetration=1.81,SpellPower=1,Spirit=0.02}},
    {id=14,label="Enhancement DPS",tab=2,icon="spell_nature_lightningshield",w={Agility=1.32,Ap=1,CritRating=33.88,HitRating=52,Intellect=1.99,MeleeDps=14.18,NatureSpellDamage=0.72,SpellDamage=1.27,SpellPenetration=2.52,SpellPower=1.27,Strength=2.2}},
    {id=16,label="Healer",tab=3,icon="spell_nature_magicimmunity",w={Healing=17,Intellect=20,Mp5=100,SpellPower=17}},
  },
  WARLOCK={
    {id=17,label="DPS",tab=1,icon="spell_shadow_deathcoil",w={CritRating=65,HitRating=100,Intellect=1,ShadowSpellDamage=5,SpellPower=5}},
  },
  WARRIOR={
    {id=741183,label="Arms DPS",tab=1,icon="ability_warrior_savageblow",w={Agility=1.71,Ap=1,CritRating=31.22,HitRating=47,MeleeDps=16.63,Strength=2.2}},
    {id=18,label="Fury DPS",tab=2,icon="ability_warrior_innerrage",w={Agility=1.7,Ap=1,CritRating=31.64,HitRating=16.9,MeleeDps=12.59,Strength=2.2}},
    {id=20,label="Mitigation Tank",tab=3,icon="inv_shield_06",w={Agility=0.51,Ap=0.27,Armor=0.04,BlockRating=0.1,BlockValue=0.61,CritRating=6.02,DefenseRating=0.2,DodgeRating=1.68,HitRating=0.4,MeleeDps=1.33,ParryRating=2.25,Stamina=1.15,Strength=0.62}},
    {id=19,label="Threat Tank",tab=3,icon="inv_shield_06",w={Agility=0.52,Ap=0.27,Armor=0.05,BlockRating=0.05,BlockValue=0.62,CritRating=6.16,DefenseRating=0.31,DodgeRating=1.68,HitRating=0.5,MeleeDps=1.35,ParryRating=2.25,Stamina=1.15,Strength=0.62}},
  },
}
