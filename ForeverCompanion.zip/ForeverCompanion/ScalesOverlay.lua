-- Forever Companion — ScalesOverlay.lua
-- Sur les récompenses de quête, les jets de butin, et (option) les sacs, la banque, le marchand et la fenêtre de butin :
--   • flèche verte (icône du jeu) : l'objet est meilleur que celui porté, d'après l'échelle active (Scales.lua) ;
--   • étoile du jeu dorée : n°1 de ma liste BiS (ma spé, phase mise en avant) ; argentée : autre objet de la liste.
local FC = ForeverCompanion
local API = ForeverCompanionAPI
local Scales = FC.Scales

-- Objets pas encore chargés par le jeu (ID) : un passage est refait à la réception de CES objets seulement.
-- (L'hôtel des ventes fait arriver des milliers de fiches d'objets : réagir à chacune redessinait tout en boucle.)
local waiting = {}

-- Icônes du jeu : étoile de la fenêtre de réputation (la même que dans la fenêtre du butin des
-- donjons), en haut à gauche ; flèche verte des sacs (amélioration), en haut à droite.
local function Badge(btn, anchor)
    local b = btn.fcScaleBadge
    if not b then
        b = CreateFrame("Frame", nil, btn)
        b.arrow = b:CreateTexture(nil, "OVERLAY")
        Scales.SetArrowTexture(b.arrow)
        b.arrow:SetSize(16, 16)
        b.star = b:CreateTexture(nil, "OVERLAY")
        Scales.SetStarTexture(b.star)
        b.star:SetSize(14, 14)
        btn.fcScaleBadge = b
    end
    b:SetFrameLevel((btn:GetFrameLevel() or 1) + 4)
    b:ClearAllPoints(); b:SetAllPoints(anchor or btn)
    b.star:ClearAllPoints(); b.star:SetPoint("TOPLEFT", b, "TOPLEFT", -4, 4)
    b.arrow:ClearAllPoints(); b.arrow:SetPoint("TOPRIGHT", b, "TOPRIGHT", 4, 4)
    return b
end

-- Décore un bouton d'objet (link = nil : rien à afficher). Renvoie flèche, rang BiS (pour les tests).
local function Decorate(btn, link, anchor)
    if not btn then return end
    if not link then
        if btn.fcScaleBadge then btn.fcScaleBadge:Hide() end
        return
    end
    local g = FC.db.global
    local up, rank = false, nil
    local on = g.scales_enabled ~= false   -- interrupteur général (Options → Tabs & features)
    if on and g.scale_arrows ~= false then
        local ev, wait = Scales.Evaluate(link)
        if wait then local id = tonumber(link:match("item:(%d+)")); if id then waiting[id] = true end end
        up = ev and ev.upgrade or false
    end
    if on and g.scale_stars ~= false then rank = Scales.BisRank(tonumber(link:match("item:(%d+)"))) end
    if not up and not rank then
        if btn.fcScaleBadge then btn.fcScaleBadge:Hide() end
        return false, nil
    end
    local b = Badge(btn, anchor)
    if up then b.arrow:Show() else b.arrow:Hide() end
    if rank then
        b.star:SetDesaturated(rank ~= 1)   -- dorée : n°1 ; grisée (argentée) : alternative
        b.star:Show()
    else
        b.star:Hide()
    end
    b:Show()
    return up, rank
end
FC.ScaleDecorate = Decorate   -- exposé pour les tests

-- ── Récompenses de quête (fenêtre de quête et journal) ────────────────────
local function QuestButtons()
    local out, seen = {}, {}
    local function add(b) if b and not seen[b] then seen[b] = true; out[#out + 1] = b end end
    for _, fr in ipairs({ _G.QuestInfoRewardsFrame, _G.MapQuestInfoRewardsFrame }) do
        if fr then
            for _, b in ipairs(fr.RewardButtons or {}) do add(b) end
            local n = fr.GetName and fr:GetName()
            if n then for i = 1, 10 do add(_G[n .. "QuestInfoItem" .. i]) end end
        end
    end
    for i = 1, 10 do add(_G["QuestInfoItem" .. i]); add(_G["QuestRewardItem" .. i]); add(_G["QuestLogItem" .. i]) end
    return out
end
local function QuestLink(b)
    if not b:IsShown() then return nil end
    if b.objectType and b.objectType ~= "item" then return nil end
    local t, i = b.type, b.GetID and b:GetID()
    if not t or not i or i < 1 then return nil end
    local name = (b.GetName and b:GetName()) or ""
    local fromLog = (_G.QuestInfoFrame and _G.QuestInfoFrame.questLog) or name:find("^QuestLog") or name:find("^MapQuestInfo")
    local ok, link
    if fromLog and GetQuestLogItemLink then ok, link = pcall(GetQuestLogItemLink, t, i); if not ok then link = nil end end
    if type(link) ~= "string" and GetQuestItemLink then ok, link = pcall(GetQuestItemLink, t, i); if not ok then link = nil end end
    return type(link) == "string" and link or nil
end
function FC:RefreshQuestRewards()
    if not self.db then return end
    for _, b in ipairs(QuestButtons()) do
        local name = b.GetName and b:GetName()
        local icon = b.Icon or (name and _G[name .. "IconTexture"]) or nil
        Decorate(b, QuestLink(b), icon)
    end
end

-- ── Jets de butin (Besoin / Cupidité) ─────────────────────────────────────
local hooked = {}
local function LootFrames()
    local out, seen = {}, {}
    local function add(f) if f and not seen[f] then seen[f] = true; out[#out + 1] = f end end
    for i = 1, (tonumber(rawget(_G, "NUM_GROUP_LOOT_FRAMES")) or 4) do add(_G["GroupLootFrame" .. i]) end
    local c = _G.GroupLootContainer
    if c and type(c.rollFrames) == "table" then for _, f in pairs(c.rollFrames) do add(f) end end
    return out
end
function FC:RefreshLootRolls()
    if not self.db then return end
    for _, f in ipairs(LootFrames()) do
        if not hooked[f] and f.HookScript then
            hooked[f] = true
            f:HookScript("OnShow", function() C_Timer.After(0, function() FC:RefreshLootRolls() end) end)
        end
        local link
        if f:IsShown() and f.rollID and GetLootRollItemLink then
            local ok, l = pcall(GetLootRollItemLink, f.rollID)
            link = ok and l or nil
        end
        local name = f.GetName and f:GetName()
        local icon = f.IconFrame or (name and _G[name .. "IconFrame"]) or nil
        Decorate(icon or f, link)
    end
end

-- ── Sacs, banque, marchand, fenêtre de butin ──────────────────────────────
-- Fenêtres du jeu lues sans toucher à leurs fonctions de mise à jour (se greffer sur Update / UpdateItems
-- des sacs modernes casse leur rafraîchissement) : on repasse à leur ouverture et quand leur contenu change.
local function MoreOn() return FC.db and FC.db.global.scale_badges_more ~= false end
local function SlotLink(bag, slot)
    local containerLink = (C_Container and C_Container.GetContainerItemLink) or rawget(_G, "GetContainerItemLink")
    if not (containerLink and bag and slot) then return nil end
    local ok, l = pcall(containerLink, bag, slot)
    return ok and type(l) == "string" and l or nil
end
-- Équipement seulement (pas de marque sur les composants, la nourriture…)
local function Gear(link)
    if not link then return nil end
    local loc = select(4, API.GetItemInfoInstant(link))
    return loc and Scales.SLOTS[loc] and link or nil
end
local function DecorateGear(btn, link)
    if not btn then return end
    Decorate(btn, MoreOn() and Gear(link) or nil)
end
local function Shown(f) return f and f.IsShown and f:IsShown() end

-- Sacs (et sacs de la banque) : liste du conteneur moderne, sac combiné, ContainerFrame1 à 13
local function BagFrames()
    local out, seen = {}, {}
    local function add(f) if f and not seen[f] then seen[f] = true; out[#out + 1] = f end end
    local box = rawget(_G, "ContainerFrameContainer")
    if box and type(box.ContainerFrames) == "table" then for _, f in ipairs(box.ContainerFrames) do add(f) end end
    add(rawget(_G, "ContainerFrameCombinedBags"))
    for i = 1, (tonumber(rawget(_G, "NUM_CONTAINER_FRAMES")) or 13) do add(rawget(_G, "ContainerFrame" .. i)) end
    return out
end
-- Boutons d'objets d'un cadre : EnumerateValidItems (moderne), sinon .Items, sinon les enfants « objet ».
-- Les sacs renvoient (numéro, bouton), la banque (bouton, true) : on garde celui des deux qui est un bouton.
local function IsButton(x) return type(x) == "table" and type(x.GetID) == "function" end
local function ItemButtons(frame)
    local out = {}
    if frame.EnumerateValidItems then
        pcall(function()
            for k, v in frame:EnumerateValidItems() do
                local b = IsButton(v) and v or (IsButton(k) and k) or nil
                if b then out[#out + 1] = b end
            end
        end)
    end
    if #out == 0 and type(frame.Items) == "table" then
        for _, b in pairs(frame.Items) do if type(b) == "table" and b.GetID then out[#out + 1] = b end end
    end
    if #out == 0 and frame.GetChildren then
        for _, c in ipairs({ frame:GetChildren() }) do
            if c.GetID and (c.GetBagID or c.hasItem ~= nil or c.icon or c.Count) then out[#out + 1] = c end
        end
    end
    return out
end
-- Sac et emplacement d'un bouton : son GetBagID (moderne) ou l'ID de son cadre (ancien)
local function BagSlot(b)
    local slot = b.GetID and b:GetID()
    local bag = b.GetBagID and b:GetBagID()
    if type(bag) ~= "number" and b.GetParent then local p = b:GetParent(); bag = p and p.GetID and p:GetID() end
    return bag, slot
end
function FC:RefreshBagBadges()
    if not self.db then return end
    for _, f in ipairs(BagFrames()) do
        if Shown(f) then for _, b in ipairs(ItemButtons(f)) do DecorateGear(b, SlotLink(BagSlot(b))) end end
    end
end

-- Banque : ancienne fenêtre (BankFrameItem1…, sac -1) ou nouvelle (BankPanel)
function FC:RefreshBankBadges()
    if not self.db then return end
    local panel = rawget(_G, "BankPanel")
    if Shown(panel) then
        for _, b in ipairs(ItemButtons(panel)) do
            local bag = (b.GetBankTabID and b:GetBankTabID()) or b.bankTabID or (b.GetBagID and b:GetBagID())
            local slot = (b.GetContainerSlotID and b:GetContainerSlotID()) or b.containerSlotID or (b.GetID and b:GetID())
            DecorateGear(b, SlotLink(bag, slot))
        end
    end
    if Shown(rawget(_G, "BankFrame")) then
        local bag = tonumber(rawget(_G, "BANK_CONTAINER")) or -1
        for i = 1, (tonumber(rawget(_G, "NUM_BANKGENERIC_SLOTS")) or 28) do
            local b = rawget(_G, "BankFrameItem" .. i)
            if b then DecorateGear(b, SlotLink(bag, b:GetID())) end
        end
    end
end

-- Marchand : onglet Marchand seulement (l'onglet Rachat réutilise les mêmes boutons)
function FC:RefreshMerchantBadges()
    if not self.db then return end
    local mf = rawget(_G, "MerchantFrame")
    local open = Shown(mf) and (mf.selectedTab or 1) == 1
    local per = tonumber(rawget(_G, "MERCHANT_ITEMS_PER_PAGE")) or 10
    local page = (mf and mf.page) or 1
    for i = 1, per do
        local b = rawget(_G, "MerchantItem" .. i .. "ItemButton")
        if b then
            local link
            if open and Shown(b) and GetMerchantItemLink then
                local ok, l = pcall(GetMerchantItemLink, (page - 1) * per + i)
                link = ok and l or nil
            end
            DecorateGear(b, link)
        end
    end
end

-- Fenêtre de butin : nouvelle (LootFrame.ScrollBox) ou ancienne (LootButton1…)
function FC:RefreshLootWindowBadges()
    if not self.db then return end
    local lf = rawget(_G, "LootFrame")
    local function link(slot)
        if not (slot and GetLootSlotLink) then return nil end
        local ok, l = pcall(GetLootSlotLink, slot)
        return ok and l or nil
    end
    local box = lf and lf.ScrollBox
    if type(box) == "table" and type(box.ForEachFrame) == "function" then
        pcall(box.ForEachFrame, box, function(el)
            local data = el.GetElementData and el:GetElementData()
            local slot = (type(data) == "table" and data.slotIndex) or (el.GetSlotIndex and el:GetSlotIndex())
            DecorateGear(el.Item or el, Shown(lf) and link(slot) or nil)
        end)
    end
    for i = 1, (tonumber(rawget(_G, "LOOTFRAME_NUMBUTTONS")) or 4) do
        local b = rawget(_G, "LootButton" .. i)
        if b then DecorateGear(b, (Shown(lf) and Shown(b)) and link(b.slot) or nil) end
    end
end

-- ── Baganator (sacs qui remplacent ceux du jeu) ───────────────────────────
-- Flèche et étoile en « icônes de coin » de Baganator (son interface prévue pour les autres addons) :
-- le joueur peut les déplacer ou les masquer dans ses réglages d'icônes. Mêmes règles que dans nos sacs
-- (équipement seulement, mêmes options), et seulement sur les objets du personnage connecté : Baganator
-- montre aussi les sacs et la banque des autres personnages, où la flèche (comparée à ce que porte CE
-- personnage) serait fausse. Pas d'« amélioration » toute faite de Baganator : s'y inscrire change un
-- de ses réglages tout seul.
-- Réponse à Baganator : vrai (afficher) ou faux (masquer) ; nil = donnée pas prête, il redemande en
-- boucle : réservé aux objets pas encore chargés par le jeu, et abandonné après quelques essais.
local bagan = { tried = false, ok = false, retries = {} }
local BAGAN_RETRIES = 30
local function BaganatorAPI()
    local b = rawget(_G, "Baganator")
    return type(b) == "table" and type(b.API) == "table" and b.API or nil
end
local function ItemID(link) return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil end
-- Objet du personnage connecté : l'emplacement (donné par Baganator, sinon celui du bouton) contient bien cet objet
local function OwnItem(details, button)
    local id = ItemID(details.itemLink)
    if not id then return false end
    local loc = details.itemLocation
    if type(loc) == "table" and type(loc.IsValid) == "function" and C_Item and C_Item.GetItemLink then
        local ok, valid = pcall(loc.IsValid, loc)
        if ok and valid then
            local ok2, l = pcall(C_Item.GetItemLink, loc)
            if ok2 then return ItemID(l) == id end
        end
    end
    if type(button) == "table" and type(button.GetBagID) == "function" and type(button.GetID) == "function" then
        local ok, bag = pcall(button.GetBagID, button)
        if ok and type(bag) == "number" then return ItemID(SlotLink(bag, button:GetID())) == id end
    end
    return false   -- objet d'un autre personnage (ou emplacement inconnu)
end
local function BaganShows(details, button, key)
    if not (FC.db and type(details) == "table") then return false end
    local g = FC.db.global
    if g.scales_enabled == false or g[key] == false or not MoreOn() then return false end
    if not Gear(details.itemLink) then return false end
    return OwnItem(details, button)
end
local function ArrowUpdate(tex, details)
    if not BaganShows(details, tex.fcButton, "scale_arrows") then return false end
    local link = details.itemLink
    local ev, wait = Scales.Evaluate(link)
    if wait then
        local n = (bagan.retries[link] or 0) + 1
        bagan.retries[link] = n
        if n <= BAGAN_RETRIES then return nil end   -- pas encore chargé : Baganator redemandera
        return false
    end
    bagan.retries[link] = nil
    return (ev and ev.upgrade) and true or false
end
local function StarUpdate(tex, details)
    if not BaganShows(details, tex.fcButton, "scale_stars") then return false end
    local rank = Scales.BisRank(ItemID(details.itemLink))
    if not rank then return false end
    tex:SetDesaturated(rank ~= 1)   -- dorée : n°1 ; grisée (argentée) : alternative
    return true
end
-- Une erreur chez nous ne doit pas casser l'affichage des sacs de Baganator
local function Safe(fn)
    return function(tex, details)
        local ok, r = pcall(fn, tex, details)
        if ok then return r end
        return false
    end
end
local function ArrowInit(button)
    local t = button:CreateTexture(nil, "OVERLAY")
    Scales.SetArrowTexture(t); t:SetSize(16, 16); t.fcButton = button
    return t
end
local function StarInit(button)
    local t = button:CreateTexture(nil, "OVERLAY")
    Scales.SetStarTexture(t); t:SetSize(14, 14); t.fcButton = button
    return t
end
-- Inscription (une seule tentative) : au chargement si Baganator est déjà là, sinon à son chargement
local function RegisterBaganator()
    if bagan.tried then return end
    local api = BaganatorAPI()
    if not (api and type(api.RegisterCornerWidget) == "function") then return end
    bagan.tried = true
    bagan.ok = pcall(function()
        api.RegisterCornerWidget("Forever Companion: BiS star", "forevercompanion_bis", Safe(StarUpdate), StarInit,
            { corner = "top_left", priority = 1 }, true)
        api.RegisterCornerWidget("Forever Companion: upgrade arrow", "forevercompanion_upgrade", Safe(ArrowUpdate), ArrowInit,
            { corner = "top_right", priority = 1 }, false)
    end)
end
FC.RegisterBaganator = RegisterBaganator
-- Équipement, échelle, liste BiS ou options changés : Baganator redessine ses icônes (au plus toutes les 0,2 s)
local baganQueued = false
function FC:RefreshBaganator()
    if not bagan.ok or baganQueued then return end
    local api = BaganatorAPI()
    if not (api and type(api.RequestItemButtonsRefresh) == "function") then return end
    baganQueued = true
    bagan.retries = {}
    C_Timer.After(0.2, function() baganQueued = false; pcall(api.RequestItemButtonsRefresh) end)
end
RegisterBaganator()

function FC:RefreshScaleOverlays()
    self:RefreshQuestRewards()
    self:RefreshLootRolls()
    self:RefreshBagBadges()
    self:RefreshBankBadges()
    self:RefreshMerchantBadges()
    self:RefreshLootWindowBadges()
    self:RefreshBaganator()
    if self.RefreshScalePreview then self:RefreshScalePreview() end
end

-- ── Aperçu (/fc preview) : voir la flèche et l'étoile sans aller en donjon ──
-- Objets de tes sacs (équipables) et de ta liste BiS, décorés comme les récompenses et les jets de butin ;
-- survol : infobulle avec la valeur d'après ton échelle.
local preview
local ICON, GAP, PER_ROW = 34, 6, 12
local function BagLinks(max)
    local out = {}
    local numSlots = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
    local itemLink = (C_Container and C_Container.GetContainerItemLink) or GetContainerItemLink
    if not numSlots or not itemLink then return out end
    for bag = 0, (tonumber(rawget(_G, "NUM_BAG_SLOTS")) or 4) do
        for slot = 1, (numSlots(bag) or 0) do
            local l = itemLink(bag, slot)
            local loc
            if l then loc = select(4, API.GetItemInfoInstant(l)) end
            if loc and Scales.SLOTS[loc] then out[#out + 1] = l end
            if #out >= max then return out end
        end
    end
    return out
end
local function BisLinks(max)
    local out, seen = {}, {}
    local cn = FC:ClassFromToken(Scales.PlayerToken())
    local db = FC.db.char
    local sn = cn and ((db.highlight_class == cn and db.highlight_spec) or select(2, FC:DetectPlayerSpec()))
    local ph = FC:GetHighlightPhase()
    local slots = cn and sn and ((FC.BisData[cn] or {})[sn] or {})[ph] or {}
    for _, se in ipairs(slots) do
        for _, it in ipairs(se.items or {}) do
            if it.rank <= 2 and it.itemId and it.itemId > 0 and not seen[it.itemId] then
                seen[it.itemId] = true
                out[#out + 1] = "item:" .. it.itemId
                if #out >= max then return out, sn, ph end
            end
        end
    end
    return out, sn, ph
end
local function PreviewRow(f, key, y, title, links)
    f[key] = f[key] or {}
    local row = f[key]
    row.title = row.title or f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.title:ClearAllPoints(); row.title:SetPoint("TOPLEFT", 16, -y); row.title:SetText(title)
    y = y + 20
    row.btns = row.btns or {}
    for i, link in ipairs(links) do
        local b = row.btns[i]
        if not b then
            b = CreateFrame("Button", nil, f)
            b:SetSize(ICON, ICON)
            b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetAllPoints()
            b:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetHyperlink(self.link)
                GameTooltip:Show()
            end)
            b:SetScript("OnLeave", function() GameTooltip:Hide() end)
            row.btns[i] = b
        end
        local col, line = (i - 1) % PER_ROW, math.floor((i - 1) / PER_ROW)
        b:ClearAllPoints(); b:SetPoint("TOPLEFT", 16 + col * (ICON + GAP), -(y + 4 + line * (ICON + GAP)))
        b.link = link
        b.icon:SetTexture(API.GetItemIcon(tonumber(link:match("item:(%d+)"))) or 134400)
        Decorate(b, link)
        b:Show()
    end
    for i = #links + 1, #row.btns do row.btns[i]:Hide() end
    if #links == 0 then
        row.empty = row.empty or f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        row.empty:ClearAllPoints(); row.empty:SetPoint("TOPLEFT", 20, -(y + 4)); row.empty:SetText("Nothing to show."); row.empty:Show()
        return y + 24
    end
    if row.empty then row.empty:Hide() end
    return y + 8 + math.ceil(#links / PER_ROW) * (ICON + GAP)
end
function FC:RefreshScalePreview()
    local f = preview
    if not f or not f:IsShown() then return end
    local s, auto = Scales.Active()
    f.info:SetText(FC.db.global.scales_enabled == false and "|cffff8c33Gear scales are turned off (Options > Tabs & features).|r" or s and ("Scale: |cffffd100" .. s.label .. "|r" .. (auto and "  |cff9d9d9d(automatic, from your talents)|r" or ""))
        or "|cffff5050No scale for your class yet: import one in the options (Gear scales).|r")
    local y = 58
    y = PreviewRow(f, "bags", y, "Your bags (equippable items)", BagLinks(PER_ROW * 2))
    local bis, sn, ph = BisLinks(PER_ROW * 2)
    y = PreviewRow(f, "bis", y + 6, "Your BiS list" .. (sn and (" — " .. sn .. ", " .. FC:PhaseLabel(ph)) or " (no spec detected)"), bis)
    f.hint:ClearAllPoints(); f.hint:SetPoint("TOPLEFT", 16, -(y + 8)); f.hint:SetPoint("RIGHT", f, "RIGHT", -16, 0)
    f:SetHeight(y + 60)
end
function FC:ShowScalePreview()
    if not preview then
        local f = API.CreateWindow("ForeverCompanionScalePreview", UIParent, 16 * 2 + PER_ROW * (ICON + GAP), 300)
        f:SetPoint("CENTER", 0, 60)
        f:SetFrameStrata("DIALOG")
        f:SetClampedToScreen(true)
        f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
        API.CloseOnEscape(f)
        API.WindowTitle(f):SetText(FC.NAME .. " — Gear scales preview")
        f.info = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.info:SetPoint("TOPLEFT", 16, -34); f.info:SetPoint("RIGHT", f, "RIGHT", -16, 0); f.info:SetJustifyH("LEFT")
        f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        f.hint:SetJustifyH("LEFT")
        f.hint:SetText("Same icons as on quest rewards and loot rolls: green arrow = better than what you wear, gold star = best item of your BiS list, grey star = alternative. "
            .. "To see them on real quest rewards, open your quest log on a quest that gives items.")
        f:SetScript("OnShow", function() FC:RefreshScalePreview() end)
        f:Hide()
        preview = f
    end
    if preview:IsShown() then preview:Hide() else preview:Show(); FC:RefreshScalePreview() end
end

-- ── Évènements ────────────────────────────────────────────────────────────
local f = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_LOGIN", "ADDON_LOADED", "QUEST_DETAIL", "QUEST_COMPLETE", "QUEST_ITEM_UPDATE", "START_LOOT_ROLL", "GET_ITEM_INFO_RECEIVED",
    "BAG_UPDATE_DELAYED", "PLAYER_EQUIPMENT_CHANGED", "BANKFRAME_OPENED", "PLAYERBANKSLOTS_CHANGED",
    "MERCHANT_SHOW", "MERCHANT_UPDATE", "LOOT_OPENED", "LOOT_SLOT_CHANGED", "LOOT_SLOT_CLEARED" }) do
    pcall(f.RegisterEvent, f, e)
end
local queued = false
local function Soon(fn)
    if queued then return end
    queued = true
    C_Timer.After(0.1, function() queued = false; fn() end)
end
-- Sacs, banque, marchand, butin : un passage tout de suite et un autre un peu après
-- (les fenêtres du jeu placent leurs boutons après l'évènement qui les ouvre)
local moreQueued = false
local function RefreshMore()
    FC:RefreshBagBadges(); FC:RefreshBankBadges(); FC:RefreshMerchantBadges(); FC:RefreshLootWindowBadges()
end
local function MoreSoon()
    if moreQueued then return end
    moreQueued = true
    C_Timer.After(0, function() moreQueued = false; RefreshMore() end)
    C_Timer.After(0.3, RefreshMore)
end
FC.ScaleBadgesSoon = MoreSoon
local hookedShow = {}
local function HookShows()
    local list = BagFrames()
    for _, n in ipairs({ "BankFrame", "BankPanel", "MerchantFrame", "LootFrame" }) do list[#list + 1] = rawget(_G, n) end
    for _, fr in ipairs(list) do
        if fr and not hookedShow[fr] and fr.HookScript then hookedShow[fr] = true; fr:HookScript("OnShow", MoreSoon) end
    end
end
f:SetScript("OnEvent", function(_, e, arg1, arg2)
    if e == "ADDON_LOADED" then
        if arg1 == "Baganator" then RegisterBaganator() end
        return
    end
    if e == "PLAYER_LOGIN" then
        RegisterBaganator()
        -- La fenêtre de quête et le journal passent tous deux par QuestInfo_Display
        if type(rawget(_G, "QuestInfo_Display")) == "function" then
            hooksecurefunc("QuestInfo_Display", function() FC:RefreshQuestRewards() end)
        end
        HookShows()
        -- Ouverture des sacs, pages et onglets du marchand, ancienne fenêtre de butin : fonctions globales du jeu
        for _, fn in ipairs({ "OpenAllBags", "ToggleAllBags", "OpenBackpack", "ToggleBackpack", "ToggleBag",
            "MerchantFrame_UpdateMerchantInfo", "MerchantFrame_Update", "BankFrameItemButton_Update", "LootFrame_Update" }) do
            if type(rawget(_G, fn)) == "function" then hooksecurefunc(fn, function() HookShows(); MoreSoon() end) end
        end
        return
    end
    if e == "BAG_UPDATE_DELAYED" or e == "PLAYER_EQUIPMENT_CHANGED" or e == "BANKFRAME_OPENED" or e == "PLAYERBANKSLOTS_CHANGED"
        or e == "MERCHANT_SHOW" or e == "MERCHANT_UPDATE" or e:find("^LOOT_") then
        HookShows(); MoreSoon()
        if e ~= "PLAYER_EQUIPMENT_CHANGED" then return end
        FC:RefreshBaganator()   -- ce qu'on porte a changé : les flèches de Baganator aussi
    end
    if e == "GET_ITEM_INFO_RECEIVED" then
        local id = tonumber(arg1)
        if not (id and waiting[id]) then return end   -- pas un objet qu'on attend : ignoré
        waiting[id] = nil
        if arg2 == false then return end              -- inconnu du serveur : rien à redessiner
        Soon(function() FC:RefreshScaleOverlays() end)
    elseif e == "START_LOOT_ROLL" then
        Soon(function() FC:RefreshLootRolls() end)
    else
        Soon(function() FC:RefreshQuestRewards() end)
    end
end)
